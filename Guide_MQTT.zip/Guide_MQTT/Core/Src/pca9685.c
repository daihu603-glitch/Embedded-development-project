/**
 * @file pca9685.c
 * @brief PCA9685 设备驱动：配置约 50 Hz PWM，输出舵机脉冲；总线访问由 servo_io 封装。
 */
#include "pca9685.h"
#include "pca9685_reg.h"
#include "servo_io.h"

#define PCA9685_PRESCALE_50HZ 121U
#define PCA9685_CHANNELS 16U

/**
 * @brief 检查设备对象、总线编号与支持的七位 I2C 地址范围。
 */
static int valid(const pca9685_t *device)
{
    return device && device->bus < 2U && device->address >= 0x40U && device->address <= 0x77U;
}

/**
 * @brief 向设备的一个寄存器写入一个字节，成功返回 1。
 */
static int write_byte(pca9685_t *device, uint8_t reg, uint8_t value)
{
    return servo_io_write(device->bus, device->address, reg, &value, 1U);
}

/**
 * @brief 设置全局 FULL_OFF 关闭全部 16 路输出；通信失败时清除设备就绪标志。
 */
pca9685_result_t pca9685_all_off(pca9685_t *device)
{
    if (!valid(device)) { return PCA9685_INVALID; }
    /* 单字节写入无需预先开启寄存器地址自增。 */
    if (!write_byte(device, PCA9685_ALL_LED_OFF_H, PCA9685_FULL_OFF)) {
        device->ready = 0U;
        return PCA9685_IO_ERROR;
    }
    return PCA9685_OK;
}

/**
 * @brief 先关闭输出，再休眠配置预分频、输出模式和自增地址；唤醒后回读寄存器确认配置。
 * 使用标称 25 MHz 内部时钟与预分频 121，得到约 50 Hz；主循环内串行调用。
 */
pca9685_result_t pca9685_init(pca9685_t *device)
{
    uint8_t mode;
    uint8_t prescale;
    const uint8_t off[4] = {0U, 0U, 0U, PCA9685_FULL_OFF};
    if (!valid(device)) { return PCA9685_INVALID; }
    device->ready = 0U;
    if (pca9685_all_off(device) != PCA9685_OK) { return PCA9685_IO_ERROR; }
    if (!servo_io_read(device->bus, device->address, PCA9685_MODE1, &mode)) { return PCA9685_IO_ERROR; }
    /* 外部时钟选择位保持到掉电或软件复位；若已置位，不能按内部 25 MHz 时钟配置。 */
    if (mode & PCA9685_EXTCLK) { return PCA9685_CONFIG_ERROR; }
    if (!write_byte(device, PCA9685_MODE1, PCA9685_SLEEP | PCA9685_AUTO_INCREMENT) ||
        !servo_io_write(device->bus, device->address, PCA9685_ALL_LED_ON_L, off, sizeof(off)) ||
        !write_byte(device, PCA9685_MODE2, PCA9685_OUTDRV) ||
        !write_byte(device, PCA9685_PRE_SCALE, PCA9685_PRESCALE_50HZ) ||
        !write_byte(device, PCA9685_MODE1, PCA9685_AUTO_INCREMENT)) { return PCA9685_IO_ERROR; }
    /* 振荡器启动至少需 500 微秒；此处等待 1 毫秒，期间所有通道仍关闭。 */
    servo_io_delay_ms(1U);
    if (!servo_io_read(device->bus, device->address, PCA9685_MODE1, &mode) ||
        !servo_io_read(device->bus, device->address, PCA9685_PRE_SCALE, &prescale)) { return PCA9685_IO_ERROR; }
    if ((mode & (PCA9685_SLEEP | PCA9685_EXTCLK | PCA9685_AUTO_INCREMENT)) != PCA9685_AUTO_INCREMENT ||
        prescale != PCA9685_PRESCALE_50HZ) { return PCA9685_CONFIG_ERROR; }
    device->ready = 1U;
    return PCA9685_OK;
}

/**
 * @brief 设置指定 CH0～CH15 的脉宽：0 关闭通道，非零只接受 1000～2000 微秒。
 * 写入成功只表示总线操作完成，实际波形和舵机运动仍需硬件验证。
 */
pca9685_result_t pca9685_set_pulse(pca9685_t *device, uint8_t channel, uint16_t pulse_us)
{
    uint16_t ticks;
    uint8_t data[4] = {0U, 0U, 0U, PCA9685_FULL_OFF};
    if (!valid(device) || channel >= PCA9685_CHANNELS ||
        (pulse_us && (pulse_us < 1000U || pulse_us > 2000U))) { return PCA9685_INVALID; }
    if (!device->ready) { return PCA9685_NOT_READY; }
    if (pulse_us) {
        /* 按 25 MHz 时钟、122 分频换算计数并四舍五入：计数 = 微秒数 × 25 / 122。 */
        ticks = (uint16_t)(((uint32_t)pulse_us * 25U + 61U) / 122U);
        data[2] = (uint8_t)ticks;
        data[3] = (uint8_t)(ticks >> 8);
    }
    if (!servo_io_write(device->bus, device->address,
                        (uint8_t)(PCA9685_LED0_ON_L + 4U * channel), data, sizeof(data))) {
        device->ready = 0U;
        return PCA9685_IO_ERROR;
    }
    return PCA9685_OK;
}
