#ifndef BOARD_WIFI_H
#define BOARD_WIFI_H

void board_wifi_init(void);
void board_wifi_process(void);

#endif
