#include "mqtt_codec.h"
#include "mqtt_endpoint.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint8_t sent[128][512];
static size_t sent_length[128];
static uint8_t sent_link[128];
static unsigned send_count;
static unsigned close_count;
static unsigned command_count;
static char last_topic[80];
static char last_command[96];
static int fail_send;

static int send_cb(uint8_t link, const uint8_t *data, size_t length)
{
    if (fail_send) { return 0; }
    assert(send_count < 128U && length <= 512U);
    memcpy(sent[send_count], data, length);
    sent_length[send_count] = length;
    sent_link[send_count++] = link;
    return 1;
}
static void close_cb(uint8_t link) { assert(link < 5U); ++close_count; }
static void command_cb(const char *topic, const char *command)
{
    ++command_count;
    strcpy(last_topic, topic);
    strcpy(last_command, command);
}
static void reset(void)
{
    send_count = close_count = command_count = 0U;
    fail_send = 0;
    mqtt_endpoint_init(send_cb, close_cb, command_cb);
}
static void feed(uint8_t link, const uint8_t *data, size_t length, uint32_t now)
{
    size_t i;
    for (i = 0U; i < length; ++i) { mqtt_endpoint_feed(link, data[i], now); }
}
static void connect_client(uint8_t link, char id, uint32_t now, uint16_t keepalive)
{
    uint8_t packet[] = {0x10, 13, 0, 4, 'M','Q','T','T',4,2,0,30,0,1,'a'};
    packet[10] = (uint8_t)(keepalive >> 8);
    packet[11] = (uint8_t)keepalive;
    packet[14] = (uint8_t)id;
    mqtt_endpoint_open(link, now);
    feed(link, packet, sizeof(packet), now);
}

static void test_wire_and_fragmentation(void)
{
    uint8_t packet[512];
    mqtt_stream_t stream;
    mqtt_publish_t message;
    size_t n;
    size_t i;
    reset();
    connect_client(0, 'a', 0, 30);
    assert(send_count == 1U && sent_length[0] == 4U && memcmp(sent[0], "\x20\x02\x00\x00", 4U) == 0);
    n = mqtt_publish(packet, sizeof(packet), "guide/rgb", "red", 0);
    assert(n == 16U && packet[0] == 0x30U && packet[1] == 14U);
    feed(0, packet, 3, 10);
    assert(command_count == 0U);
    feed(0, packet + 3, n - 3, 20);
    assert(command_count == 1U && strcmp(last_topic, "guide/rgb") == 0 && strcmp(last_command, "red") == 0);
    mqtt_stream_reset(&stream);
    for (i = 0U; i < n; ++i) { assert(mqtt_stream_feed(&stream, packet[i]) == (i + 1U == n ? 1 : 0)); }
    assert(mqtt_read_publish(stream.bytes, stream.length, &message));
    assert(message.payload_length == 3U);
    assert(!mqtt_read_publish(packet, n - 1U, &message));
    assert(mqtt_publish(packet, 8U, "guide/rgb", "red", 0) == 0U);
}

static void test_subscriptions_and_two_clients(void)
{
    uint8_t packet[512];
    size_t n;
    const uint8_t ping[] = {0xC0, 0};
    reset();
    connect_client(0, 'a', 0, 30);
    connect_client(1, 'b', 0, 30);
    n = mqtt_subscribe(packet, sizeof(packet), "guide/#", 7U);
    feed(1, packet, n, 10);
    assert(sent_link[2] == 1 && sent_length[2] == 5 && memcmp(sent[2], "\x90\x03\x00\x07\x00", 5) == 0);
    n = mqtt_publish(packet, sizeof(packet), "guide/rgb", "blue", 0);
    feed(0, packet, n, 20);
    assert(command_count == 1 && send_count == 4 && sent_link[3] == 1);
    feed(0, ping, sizeof(ping), 30);
    assert(sent[4][0] == 0xD0 && sent[4][1] == 0);
    mqtt_endpoint_publish("guide/state", "{\"rgb\":4}");
    assert(send_count == 6 && sent_link[5] == 1);
    /* Duplicate client IDs disconnect the previous connection. */
    connect_client(2, 'a', 40, 30);
    assert(close_count == 1 && mqtt_endpoint_clients() == 2);
}

static void test_malformed_and_limits(void)
{
    const uint8_t oversized[] = {0x30, 0xff, 0x7f};
    const uint8_t invalid_length[] = {0x30, 0x80, 0x80, 0x80, 0x80};
    uint8_t packet[512];
    size_t n;
    reset(); connect_client(0, 'a', 0, 30); feed(0, oversized, sizeof(oversized), 1); assert(close_count == 1);
    reset(); connect_client(0, 'a', 0, 30); feed(0, invalid_length, sizeof(invalid_length), 1); assert(close_count == 1);
    reset(); connect_client(0, 'a', 0, 30);
    n = mqtt_publish(packet, sizeof(packet), "guide/beep", "500", 1);
    feed(0, packet, n, 1); assert(close_count == 1 && command_count == 0); /* Retained commands never execute. */
    reset(); connect_client(0, 'a', 0, 30);
    n = mqtt_subscribe(packet, sizeof(packet), "guide/#/bad", 1);
    feed(0, packet, n, 1); assert(close_count == 1);
    reset(); connect_client(0, 'a', 0, 30);
    fail_send = 1; feed(0, (const uint8_t *)"\xc0\x00", 2, 1); assert(close_count == 1);
    reset(); mqtt_endpoint_open(0, 0); feed(0, (const uint8_t *)"\xc0\x00", 2, 1); assert(close_count == 1);
}

static void test_timeouts_reuse_and_wildcards(void)
{
    uint8_t packet[512];
    size_t n;
    reset(); connect_client(0, 'a', 0xfffffff0U, 1);
    mqtt_endpoint_process(1000); assert(close_count == 0);
    mqtt_endpoint_process(1600); assert(close_count == 1);
    reset(); mqtt_endpoint_open(0, 0); mqtt_endpoint_process(10001); assert(close_count == 1);
    reset(); connect_client(0, 'a', 0, 0);
    feed(0, (const uint8_t *)"\x30\x50", 2, 100); mqtt_endpoint_process(5101); assert(close_count == 1);
    reset(); connect_client(0, 'a', 0, 30);
    n = mqtt_subscribe(packet, sizeof(packet), "guide/+", 1);
    feed(0, packet, n, 1);
    mqtt_endpoint_publish("guide/state", "ok"); assert(send_count == 3);
    mqtt_endpoint_publish("guide/one/two", "no"); assert(send_count == 3);
    mqtt_endpoint_closed(0); connect_client(0, 'b', 10, 30);
    mqtt_endpoint_publish("guide/state", "no old subscription"); assert(send_count == 4);
}

int main(void)
{
    test_wire_and_fragmentation();
    test_subscriptions_and_two_clients();
    test_malformed_and_limits();
    test_timeouts_reuse_and_wildcards();
    puts("PASS: MQTT wire format, fragments, subscriptions, routing, malformed inputs, limits, timeouts, reuse");
    return 0;
}
