/**
 * @file app_servo.c
 * @brief 舵机命令层：把全局舵机编号和目标角度转换成对应 PCA9685 通道的脉宽。
 */
#include "app_servo.h"
#include "pca9685.h"
#include <stdio.h>
#include <string.h>

#define SERVO_PER_BOARD 9U
#define SERVO_COUNT 18U
#define SERVO_MIN_DEG 45U
#define SERVO_MAX_DEG 135U
/* 两块模块使用独立 I2C 总线，因此均可保留默认七位地址 0x40。 */
static pca9685_t devices[2] = {{0U, 0x40U, 0U}, {1U, 0x40U, 0U}};

/**
 * @brief 启动时尝试关闭两块模块的输出；模块缺失不阻塞 Wi-Fi 启动，也不自动指定角度。
 */
void app_servo_init(void)
{
    uint8_t i;
    /* 仅 STM32 复位时，PCA9685 可能仍保留旧 PWM，先尝试关闭。
     * 未接模块不阻塞网络启动；此处不自动控制舵机转到某个角度。 */
    for (i = 0U; i < 2U; ++i) {
        devices[i].ready = 0U;
        (void)pca9685_all_off(&devices[i]);
    }
}

/**
 * @brief 读取最多三位无符号十进制数；成功时推进字符指针并返回 1，格式错误返回 0。
 */
static int number(const char **cursor, uint16_t *value)
{
    uint16_t result = 0U;
    uint8_t digits = 0U;
    const char *p = *cursor;
    while (*p >= '0' && *p <= '9') {
        if (++digits > 3U) { return 0; }
        result = (uint16_t)(result * 10U + (uint16_t)(*p++ - '0'));
    }
    if (!digits) { return 0; }
    *cursor = p;
    *value = result;
    return 1;
}

/**
 * @brief 处理 <编号> <角度|off>、off 和 status；回复写入 reply，capacity 为缓冲区字节数。
 * 编号 0～8 对应 I2C1 的 CH0～CH8；编号 9～17 对应 I2C2 的 CH0～CH8。
 * 角度仅允许 45～135；首次使用某块模块时才配置其 PWM 参数。
 */
void app_servo_command(const char *payload, char *reply, size_t capacity)
{
    uint16_t id, angle, pulse;
    uint8_t board, channel;
    pca9685_result_t result, second;
    const char *p = payload;
    if (!payload || !reply || !capacity) { return; }
    if (strcmp(payload, "status") == 0) {
        (void)snprintf(reply, capacity, "servo configured=%u,%u; ids=0..17; range=45..135",
                       devices[0].ready, devices[1].ready);
        return;
    }
    if (strcmp(payload, "off") == 0) {
        result = pca9685_all_off(&devices[0]);
        second = pca9685_all_off(&devices[1]);
        (void)snprintf(reply, capacity, "servo off: I2C1=%s I2C2=%s",
                       result == PCA9685_OK ? "ok" : "error", second == PCA9685_OK ? "ok" : "error");
        return;
    }
    if (!number(&p, &id) || id >= SERVO_COUNT || *p++ != ' ') { goto invalid; }
    if (strcmp(p, "off") == 0) { pulse = 0U; }
    else {
        if (!number(&p, &angle) || *p || angle < SERVO_MIN_DEG || angle > SERVO_MAX_DEG) { goto invalid; }
        /* 使用保守的标称映射：45 度对应 1000、90 度对应 1500、135 度对应 2000 微秒。
         * 实际机械角度取决于舵机型号与安装方式，需要单独校准。 */
        pulse = (uint16_t)(1000U + ((uint32_t)(angle - SERVO_MIN_DEG) * 1000U + 45U) / 90U);
    }
    board = (uint8_t)(id / SERVO_PER_BOARD);
    channel = (uint8_t)(id % SERVO_PER_BOARD);
    result = PCA9685_OK;
    if (!devices[board].ready) { result = pca9685_init(&devices[board]); }
    if (result == PCA9685_OK) { result = pca9685_set_pulse(&devices[board], channel, pulse); }
    if (result != PCA9685_OK) {
        (void)snprintf(reply, capacity, "error servo %u: I2C%u code=%u (check wiring/power/address)",
                       (unsigned)id, (unsigned)(board + 1U), (unsigned)result);
        return;
    }
    (void)snprintf(reply, capacity, "ok servo %u pulse=%u us", (unsigned)id, (unsigned)pulse);
    return;
invalid:
    (void)snprintf(reply, capacity, "error servo: use <0..17> <45..135|off>, off, status");
}
