@echo off
powershell.exe -NoProfile -STA -WindowStyle Hidden -File "%~dp0tools\serial-helper.ps1"
