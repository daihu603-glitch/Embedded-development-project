#include "app_mqtt.h"
#include "board_io.h"
#include "mqtt_codec.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint32_t now;
static uint8_t rx[16384];
static size_t rx_head, rx_tail;
static uint8_t rgb;
static uint32_t beep_end;
static size_t expected_payload;
static unsigned send_link;
static uint8_t last_payload[512];
static size_t last_payload_length;
static unsigned transmitted;
static unsigned reset_count;
static int ready;
static int fallback;
static int omit_prompt;
static int close_during_prompt;
static char last_log[256];
static int simulated_rx_error;
static unsigned legacy_ip_accepted;
static int reject_ip;

static void inject(const char *text)
{
    size_t length = strlen(text);
    assert(rx_head + length < sizeof(rx));
    memcpy(rx + rx_head, text, length); rx_head += length;
}
static void ipd(unsigned link, const uint8_t *packet, size_t length)
{
    char header[40];
    (void)snprintf(header, sizeof(header), "+IPD,%u,%u:", link, (unsigned)length);
    inject(header);
    assert(rx_head + length < sizeof(rx));
    memcpy(rx + rx_head, packet, length); rx_head += length;
}
int board_io_init(void) { return 1; }
void board_io_process(void) { }
uint32_t board_io_now(void) { return now; }
int board_io_wifi_read(uint8_t *byte)
{
    if (rx_head == rx_tail) { rx_head = rx_tail = 0; return 0; }
    *byte = rx[rx_tail++]; return 1;
}
int board_io_console_read(uint8_t *byte) { (void)byte; return 0; }
int board_io_wifi_tx_busy(void) { return 0; }
int board_io_wifi_fault(void) { int result = simulated_rx_error; simulated_rx_error = 0; return result; }
void board_io_wifi_prepare_rx(void) { rx_head = rx_tail = 0; simulated_rx_error = 0; }
void board_io_log(const char *text)
{
    (void)snprintf(last_log, sizeof(last_log), "%s", text);
    if (strstr(text, "[READY]")) { ready = 1; }
}
void board_io_wifi_reset(int asserted)
{
    if (asserted) { ++reset_count; rx_head = rx_tail = 0; expected_payload = 0; }
}
void board_io_rgb(uint8_t mask) { rgb = mask; }
uint8_t board_io_rgb_get(void) { return rgb; }
void board_io_beep(uint32_t ms) { beep_end = ms ? now + ms : 0; }
int board_io_beep_active(void) { return beep_end && (int32_t)(beep_end - now) > 0; }

int board_io_wifi_send(const uint8_t *data, size_t length)
{
    char command[256];
    unsigned n;
    if (expected_payload) {
        assert(length == expected_payload && length <= sizeof(last_payload));
        memcpy(last_payload, data, length); last_payload_length = length;
        expected_payload = 0; ++transmitted;
        inject("\r\nSEND OK\r\n");
        return 1;
    }
    assert(length < sizeof(command));
    memcpy(command, data, length); command[length] = 0;
    if (sscanf(command, "AT+CIPSEND=%u,%u", &send_link, &n) == 2) {
        expected_payload = n;
        if (close_during_prompt) { inject("\r\n0,CLOSED\r\n0,CONNECT\r\nOK\r\n> "); }
        else if (!omit_prompt) { inject("\r\nOK\r\n> "); }
    } else if (strstr(command, "AT+CIPCLOSE=")) { inject("\r\n0,CLOSED\r\nOK\r\n"); }
    else if (fallback && strstr(command, "_CUR")) { inject("\r\nERROR\r\n"); }
    else if (strncmp(command, "AT+CIPAP=", 9U) == 0) {
        if (!reject_ip && strcmp(command, "AT+CIPAP=\"192.168.4.1\"\r\n") == 0) {
            ++legacy_ip_accepted;
            inject("\r\nOK\r\n");
        } else { inject("\r\nERROR\r\n"); }
    }
    else if (fallback && strstr(command, "AT+CIPDINFO=")) { inject("\r\nERROR\r\n"); }
    else if (strstr(command, "AT+GMR")) { inject("AT version:0.22.0.0\r\nSDK version:1.0.0\r\nOK\r\n"); }
    else { inject("\r\nOK\r\n"); }
    return 1;
}

static void tick(unsigned count)
{
    unsigned i;
    for (i = 0; i < count; ++i) { now += 10; app_mqtt_process(); }
}

int main(void)
{
    uint8_t connect[] = {0x10,13,0,4,'M','Q','T','T',4,2,0,30,0,1,'a'};
    uint8_t packet[512];
    size_t length;
    unsigned i;
    fallback = 1; /* Verify legacy syntax fallback before hardware testing. */
    app_mqtt_init();
    simulated_rx_error = 1;
    inject("boot bytes at another baud rate without newline");
    tick(400); assert(ready && reset_count == 1 && legacy_ip_accepted == 1);
    inject("0,CONNECT\r\n"); ipd(0, connect, sizeof(connect)); tick(10);
    assert(last_payload_length == 4 && last_payload[0] == 0x20 && last_payload[3] == 0);
    for (i = 0; i < 100; ++i) {
        length = mqtt_publish(packet, sizeof(packet), "guide/rgb", (i & 1) ? "red" : "blue", 0);
        ipd(0, packet, 4); tick(1); ipd(0, packet + 4, length - 4); tick(2);
        assert(rgb == ((i & 1) ? 1 : 4));
    }
    length = mqtt_publish(packet, sizeof(packet), "guide/beep", "100", 0);
    ipd(0, packet, length); tick(1); assert(board_io_beep_active()); tick(11); assert(!board_io_beep_active());
    length = mqtt_publish(packet, sizeof(packet), "guide/beep", "99999", 0);
    ipd(0, packet, length); tick(1); assert(!board_io_beep_active());
    /* A peer CLOSE is consumed separately from the final CIPSEND result. */
    inject("0,CLOSED\r\n0,CONNECT\r\n"); ipd(0, connect, sizeof(connect)); tick(10); assert(last_payload[0] == 0x20);
    /* Missing prompt triggers bounded hardware reset and setup retry. */
    omit_prompt = 1;
    ipd(0, (const uint8_t *)"\xc0\x00", 2); tick(900); assert(reset_count >= 2);
    omit_prompt = 0;
    tick(400);
    inject("0,CONNECT\r\n"); ipd(0, connect, sizeof(connect)); tick(10);
    /* Link reuse during CIPSEND must not transmit the old payload. */
    close_during_prompt = 1;
    i = transmitted;
    ipd(0, (const uint8_t *)"\xc0\x00", 2); tick(2);
    assert(transmitted == i);
    i = reset_count;
    tick(310); assert(reset_count > i);
    /* Do not report READY when even the legacy IP command fails. */
    reject_ip = 1; ready = 0;
    app_mqtt_init(); tick(400); assert(!ready);
    puts("PASS: legacy single-IP setup, IP failure stays offline, MQTT handshake, 100 split commands, beep limits, reconnect, timeout recovery, close during send");
    return 0;
}
