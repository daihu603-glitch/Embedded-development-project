"""Re-add user modules after CubeMX regeneration; never touch generated init."""
from pathlib import Path
import re
import shutil

root = Path(__file__).resolve().parents[1]
project = root / 'MDK-ARM' / 'Guide_MQTT.uvprojx'
modules = ['board_io.c', 'mqtt_codec.c', 'mqtt_endpoint.c', 'esp_at.c', 'app_mqtt.c']
text = project.read_text(encoding='utf-8-sig')
if '<GroupName>Application/User/MQTT</GroupName>' not in text:
    shutil.copy2(project, project.with_suffix('.uvprojx.before-mqtt.bak'))
    files = '\n'.join(
        f'            <File><FileName>{name}</FileName><FileType>1</FileType>'
        f'<FilePath>../Core/Src/{name}</FilePath></File>' for name in modules)
    group = ('      <Group>\n        <GroupName>Application/User/MQTT</GroupName>\n'
             '        <Files>\n' + files + '\n        </Files>\n      </Group>\n')
    assert '</Groups>' in text
    text = text.replace('</Groups>', group + '    </Groups>', 1)
    project.write_text(text, encoding='utf-8', newline='\r\n')
print('Keil MQTT source group ready:', ', '.join(modules))

# Only check hooks; do not overwrite a user-edited main.c.
main = (root / 'Core' / 'Src' / 'main.c').read_text(encoding='utf-8-sig')
for hook in ['#include "app_mqtt.h"', 'app_mqtt_init();', 'app_mqtt_process();']:
    if hook not in main:
        raise SystemExit('Missing USER CODE hook: ' + hook)

