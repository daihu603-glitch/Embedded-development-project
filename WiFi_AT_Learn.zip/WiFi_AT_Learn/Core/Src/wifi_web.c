#include "wifi_web.h"

#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* Legacy reference: Espressif 4a-esp8266_at_instruction_set_en_v1.5.4_0.pdf,
 * May 2016: CWMODE_CUR, CWSAP_CUR, CIPAP_CUR, CWDHCP_CUR, CIPSERVER,
 * CIPSEND, CIPCLOSE, CIPDINFO, +IPD. No modern HTTP or passive RX commands. */
#define WIFI_LINK_COUNT 5U
#define WIFI_REQUEST_LINE_SIZE 160U
#define WIFI_AT_LINE_SIZE 192U
#define WIFI_REPLY_SIZE 1800U
#define WIFI_BOOT_WAIT_MS 1500U
#define WIFI_COMMAND_TIMEOUT_MS 5000U
#define WIFI_RETRY_WAIT_MS 3000U
#define WIFI_HTTP_TIMEOUT_MS 10000U

typedef enum
{
  WIFI_BOOT_WAIT,
  WIFI_INIT_SEND,
  WIFI_INIT_WAIT,
  WIFI_READY,
  WIFI_RESPONSE_COMMAND,
  WIFI_RESPONSE_PROMPT,
  WIFI_RESPONSE_BODY,
  WIFI_RESPONSE_RESULT,
  WIFI_CLOSE_SEND,
  WIFI_CLOSE_WAIT,
  WIFI_RETRY_WAIT
} wifi_state_t;

typedef enum
{
  WEB_PAGE,
  WEB_LED_ON,
  WEB_LED_OFF,
  WEB_NOT_FOUND,
  WEB_BAD_REQUEST
} web_request_t;

typedef struct
{
  char first_line[WIFI_REQUEST_LINE_SIZE];
  uint16_t length;
  uint32_t header_end;
  uint32_t last_tick;
  bool first_line_done;
  bool pending;
  bool handled;
  bool active;
  bool too_long;
  web_request_t request;
} web_connection_t;

typedef struct
{
  const char *text;
  bool allow_error;
} wifi_init_command_t;

static const wifi_init_command_t init_commands[] =
{
  {"AT\r\n", false},
  {"ATE0\r\n", false},
  {"AT+CIPSERVER=0\r\n", true},
  /* STM32 may restart while ESP retains its previous server and links.
   * Legacy firmware requires single connection mode before CIPMODE=0. */
  {"AT+CIPCLOSE=5\r\n", true},
  {"AT+CIPMUX=0\r\n", false},
  {"AT+CIPMODE=0\r\n", false},
  {"AT+CWMODE_CUR=2\r\n", false},
  {"AT+CWSAP_CUR=\"STM32_LED\",\"12345678\",6,3\r\n", false},
  {"AT+CIPAP_CUR=\"192.168.4.1\",\"192.168.4.1\",\"255.255.255.0\"\r\n", false},
  {"AT+CWDHCP_CUR=0,1\r\n", false},
  {"AT+CIPMUX=1\r\n", false},
  {"AT+CIPDINFO=0\r\n", false},
  {"AT+CIPSERVER=1,80\r\n", false},
  {"AT+CIPSTO=15\r\n", false}
};

static const char web_page_format[] =
  "<!doctype html><html lang=zh-CN><meta charset=utf-8>"
  "<meta name=viewport content='width=device-width,initial-scale=1'>"
  "<title>STM32 灯光控制</title><style>"
  "*{box-sizing:border-box}body{margin:0;background:#101923;color:#edf4fa;"
  "font:16px system-ui,sans-serif}main{max-width:460px;margin:12vh auto;padding:28px}"
  "small{color:#95aabd}h1{font-size:32px;margin:14px 0}p{line-height:1.7}"
  ".state{padding:22px;background:#1b2b3a;border-radius:16px;margin:28px 0}"
  "strong{font-size:28px}a{display:block;text-align:center;text-decoration:none;"
  "padding:17px;border-radius:12px;margin:12px 0;color:#10202a;background:#75dfc1}"
  ".off{color:#edf4fa;background:#304658}.note{font-size:13px;color:#95aabd}"
  "</style><main><small>STM32F103 · ESP8266</small><h1>灯光控制</h1>"
  "<p>手机发出指令，STM32 控制板上的 LED2。</p>"
  "<div class=state>LED2 · PB15<br><strong>%s</strong></div>"
  "<a href='/on'>开灯</a><a class=off href='/off'>关灯</a>"
  "<p class=note>LED1 闪烁表示程序正在运行。点击按钮后页面会更新。</p></main></html>";

static wifi_web_io_t board;
static wifi_state_t state;
static web_connection_t connections[WIFI_LINK_COUNT];
static uint32_t state_tick;
static uint32_t payload_remaining;
static uint32_t payload_link;
static uint32_t payload_tick;
static uint16_t at_line_length;
static uint16_t reply_length;
static uint8_t init_step;
static uint8_t response_link;
static bool led_on;
static bool restart_needed;
static bool at_line_overflow;
static bool response_closed;
static char at_line[WIFI_AT_LINE_SIZE];
static char command_buffer[64];
static char response_buffer[WIFI_REPLY_SIZE];
static char page_buffer[1400];

static void wifi_change_state(wifi_state_t next, uint32_t now)
{
  state = next;
  state_tick = now;
}

static void wifi_retry(const char *reason, uint32_t now)
{
  board.log(reason);
  wifi_change_state(WIFI_RETRY_WAIT, now);
}

static void wifi_reset_connections(void)
{
  memset(connections, 0, sizeof(connections));
}

static void wifi_finish_response(uint32_t now)
{
  wifi_change_state(response_closed ? WIFI_READY : WIFI_CLOSE_SEND, now);
}

/* Parsing decimal ourselves avoids scanf type and overflow ambiguities. */
static bool wifi_decimal(const char **cursor, uint32_t *value)
{
  uint32_t result = 0U;
  const char *text = *cursor;
  if ((*text < '0') || (*text > '9'))
  {
    return false;
  }
  while ((*text >= '0') && (*text <= '9'))
  {
    uint32_t digit = (uint32_t)(*text - '0');
    if (result > (65535U - digit) / 10U)
    {
      return false;
    }
    result = result * 10U + digit;
    text++;
  }
  *cursor = text;
  *value = result;
  return true;
}

static bool wifi_parse_ipd(void)
{
  const char *cursor = at_line + 5;
  uint32_t link;
  uint32_t length;
  if (!wifi_decimal(&cursor, &link) || (*cursor++ != ',') ||
      !wifi_decimal(&cursor, &length) || (*cursor != ':') ||
      (cursor[1] != '\0'))
  {
    return false;
  }
  /* Even invalid link IDs are drained by their declared payload length. */
  payload_link = link;
  payload_remaining = length;
  return true;
}

static web_request_t web_classify(const char *line)
{
  if (strncmp(line, "GET / HTTP/1.", 13U) == 0)
  {
    return WEB_PAGE;
  }
  if (strncmp(line, "GET /on HTTP/1.", 15U) == 0)
  {
    return WEB_LED_ON;
  }
  if (strncmp(line, "GET /off HTTP/1.", 16U) == 0)
  {
    return WEB_LED_OFF;
  }
  return WEB_NOT_FOUND;
}

static void web_feed(uint8_t byte, uint32_t now)
{
  web_connection_t *connection;
  if (payload_link >= WIFI_LINK_COUNT)
  {
    return;
  }
  connection = &connections[payload_link];
  if (connection->handled || connection->pending)
  {
    return;
  }
  connection->active = true;
  connection->last_tick = now;
  if (!connection->first_line_done)
  {
    if (byte == '\n')
    {
      connection->first_line[connection->length] = '\0';
      connection->request = connection->too_long ? WEB_BAD_REQUEST :
                            web_classify(connection->first_line);
      connection->first_line_done = true;
    }
    else if (connection->length < WIFI_REQUEST_LINE_SIZE - 1U)
    {
      connection->first_line[connection->length++] = (char)byte;
    }
    else
    {
      connection->too_long = true;
    }
  }
  connection->header_end = (connection->header_end << 8) | byte;
  /* Do not reply until all HTTP headers have arrived, across any +IPD frames. */
  if (connection->header_end == 0x0D0A0D0AU)
  {
    connection->pending = true;
  }
}

static void wifi_line_received(uint32_t now)
{
  uint32_t link;
  const char *cursor;
  if (strcmp(at_line, "ready") == 0)
  {
    restart_needed = true;
    board.log("\r\n[WiFi] Module reboot detected.\r\n");
    return;
  }
  cursor = at_line;
  if (wifi_decimal(&cursor, &link) && (link < WIFI_LINK_COUNT))
  {
    if (strcmp(cursor, ",CONNECT") == 0)
    {
      memset(&connections[link], 0, sizeof(connections[link]));
    }
    else if (strcmp(cursor, ",CLOSED") == 0)
    {
      memset(&connections[link], 0, sizeof(connections[link]));
      if ((link == response_link) && (state >= WIFI_RESPONSE_COMMAND) &&
          (state <= WIFI_CLOSE_WAIT))
      {
        response_closed = true;
        /* CLOSED is unsolicited. Drain the outstanding command's terminal
         * result before issuing another command, even if its link is gone. */
        if ((state == WIFI_RESPONSE_COMMAND) || (state == WIFI_CLOSE_SEND))
        {
          wifi_change_state(WIFI_READY, now);
        }
      }
    }
  }
  if (state == WIFI_INIT_WAIT)
  {
    if ((strcmp(at_line, "OK") == 0) ||
        (init_commands[init_step].allow_error && (strcmp(at_line, "ERROR") == 0)))
    {
      init_step++;
      wifi_change_state(WIFI_INIT_SEND, now);
    }
    else if ((strcmp(at_line, "ERROR") == 0) || (strcmp(at_line, "FAIL") == 0))
    {
      wifi_retry("\r\n[WiFi] Setup command failed; retrying.\r\n", now);
    }
  }
  else if (state == WIFI_RESPONSE_RESULT)
  {
    if (strcmp(at_line, "SEND OK") == 0)
    {
      wifi_finish_response(now);
    }
    else if ((strcmp(at_line, "SEND FAIL") == 0) || (strcmp(at_line, "ERROR") == 0))
    {
      wifi_finish_response(now);
    }
  }
  else if ((state == WIFI_RESPONSE_PROMPT) && (strcmp(at_line, "ERROR") == 0))
  {
    wifi_finish_response(now);
  }
  else if ((state == WIFI_CLOSE_WAIT) &&
           ((strcmp(at_line, "OK") == 0) || (strcmp(at_line, "ERROR") == 0)))
  {
    if (!response_closed)
    {
      memset(&connections[response_link], 0, sizeof(connections[response_link]));
    }
    wifi_change_state(WIFI_READY, now);
  }
}

void wifi_web_feed(uint8_t byte, uint32_t now)
{
  if (payload_remaining != 0U)
  {
    web_feed(byte, now);
    payload_remaining--;
    payload_tick = now;
    return;
  }
  if ((byte == '>') && (state == WIFI_RESPONSE_PROMPT))
  {
    at_line_length = 0U;
    at_line_overflow = false;
    wifi_change_state(WIFI_RESPONSE_BODY, now);
    return;
  }
  if (byte == '+')
  {
    at_line_length = 0U;
    at_line_overflow = false;
  }
  if (byte == '\r')
  {
    return;
  }
  if (byte == '\n')
  {
    if (!at_line_overflow)
    {
      at_line[at_line_length] = '\0';
      wifi_line_received(now);
    }
    at_line_length = 0U;
    at_line_overflow = false;
    return;
  }
  if (at_line_length < WIFI_AT_LINE_SIZE - 1U)
  {
    at_line[at_line_length++] = (char)byte;
    at_line[at_line_length] = '\0';
    if ((byte == ':') && (strncmp(at_line, "+IPD,", 5U) == 0))
    {
      if (!wifi_parse_ipd())
      {
        board.log("\r\n[WiFi] Invalid +IPD header ignored.\r\n");
      }
      payload_tick = now;
      at_line_length = 0U;
      at_line_overflow = false;
    }
  }
  else
  {
    at_line_overflow = true;
  }
}

static bool web_build_response(web_request_t request)
{
  const char *status = "200 OK";
  const char *body = page_buffer;
  int32_t body_length;
  int32_t header_length;
  if (request == WEB_LED_ON)
  {
    led_on = true;
    board.set_led(true);
    board.log("\r\n[LED2] ON\r\n");
  }
  else if (request == WEB_LED_OFF)
  {
    led_on = false;
    board.set_led(false);
    board.log("\r\n[LED2] OFF\r\n");
  }
  body_length = snprintf(page_buffer, sizeof(page_buffer), web_page_format,
                         led_on ? "已开启" : "已关闭");
  if (request == WEB_NOT_FOUND)
  {
    status = "404 Not Found";
    body = "Not found";
    body_length = 9;
  }
  else if (request == WEB_BAD_REQUEST)
  {
    status = "400 Bad Request";
    body = "Bad request";
    body_length = 11;
  }
  if ((body_length < 0) || ((uint32_t)body_length >= sizeof(page_buffer)))
  {
    return false;
  }
  header_length = snprintf(response_buffer, sizeof(response_buffer),
      "HTTP/1.1 %s\r\nContent-Type: text/html; charset=utf-8\r\n"
      "Content-Length: %lu\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n",
      status, (unsigned long)body_length);
  if ((header_length < 0) ||
      ((uint32_t)(header_length + body_length) >= sizeof(response_buffer)))
  {
    return false;
  }
  memcpy(response_buffer + header_length, body, (size_t)body_length);
  reply_length = (uint16_t)(header_length + body_length);
  return true;
}

void wifi_web_init(const wifi_web_io_t *io, uint32_t now)
{
  board = *io;
  led_on = false;
  restart_needed = false;
  init_step = 0U;
  payload_remaining = 0U;
  at_line_length = 0U;
  at_line_overflow = false;
  response_closed = false;
  wifi_reset_connections();
  board.set_led(false);
  board.log("\r\n[WiFi] Starting AP setup for legacy AT firmware.\r\n");
  wifi_change_state(WIFI_BOOT_WAIT, now);
}

bool wifi_web_is_ready(void)
{
  return (state >= WIFI_READY) && (state <= WIFI_CLOSE_WAIT);
}

void wifi_web_rx_lost(void)
{
  restart_needed = true;
}

void wifi_web_process(uint32_t now)
{
  uint8_t link;
  int32_t length;
  if (!board.tx_ready())
  {
    return;
  }
  if ((payload_remaining != 0U) &&
      ((uint32_t)(now - payload_tick) >= WIFI_COMMAND_TIMEOUT_MS))
  {
    payload_remaining = 0U;
    at_line_length = 0U;
    at_line_overflow = false;
    wifi_retry("\r\n[WiFi] Incomplete +IPD frame timed out; restarting setup.\r\n", now);
  }
  if (restart_needed)
  {
    restart_needed = false;
    payload_remaining = 0U;
    at_line_length = 0U;
    at_line_overflow = false;
    init_step = 0U;
    wifi_reset_connections();
    wifi_change_state(WIFI_BOOT_WAIT, now);
  }
  switch (state)
  {
    case WIFI_BOOT_WAIT:
      if ((uint32_t)(now - state_tick) >= WIFI_BOOT_WAIT_MS)
      {
        wifi_change_state(WIFI_INIT_SEND, now);
      }
      break;

    case WIFI_INIT_SEND:
      if (init_step >= sizeof(init_commands) / sizeof(init_commands[0]))
      {
        board.log("\r\n[READY] SSID: STM32_LED | Password: 12345678\r\n"
                  "[READY] Open http://192.168.4.1 | LED2=PB15\r\n");
        wifi_change_state(WIFI_READY, now);
      }
      else if (board.write((const uint8_t *)init_commands[init_step].text,
                           (uint16_t)strlen(init_commands[init_step].text)))
      {
        board.log("\r\n[AT TX] ");
        board.log(init_commands[init_step].text);
        wifi_change_state(WIFI_INIT_WAIT, now);
      }
      break;

    case WIFI_INIT_WAIT:
      if ((uint32_t)(now - state_tick) >= WIFI_COMMAND_TIMEOUT_MS)
      {
        wifi_retry("\r\n[WiFi] Setup timeout; check UART2, jumpers and ESP reset.\r\n", now);
      }
      break;

    case WIFI_READY:
      for (link = 0U; link < WIFI_LINK_COUNT; link++)
      {
        web_connection_t *connection = &connections[link];
        if (connection->active && !connection->handled && !connection->pending &&
            ((uint32_t)(now - connection->last_tick) >= WIFI_HTTP_TIMEOUT_MS))
        {
          response_link = link;
          response_closed = false;
          connection->handled = true;
          wifi_change_state(WIFI_CLOSE_SEND, now);
          break;
        }
        if (connection->pending)
        {
          response_link = link;
          response_closed = false;
          connection->pending = false;
          connection->handled = true;
          if (web_build_response(connection->request))
          {
            wifi_change_state(WIFI_RESPONSE_COMMAND, now);
          }
          else
          {
            wifi_change_state(WIFI_CLOSE_SEND, now);
          }
          break;
        }
      }
      break;

    case WIFI_RESPONSE_COMMAND:
      length = snprintf(command_buffer, sizeof(command_buffer),
                        "AT+CIPSEND=%u,%u\r\n", (unsigned int)response_link,
                        (unsigned int)reply_length);
      if ((length > 0) && ((uint32_t)length < sizeof(command_buffer)) &&
          board.write((const uint8_t *)command_buffer, (uint16_t)length))
      {
        wifi_change_state(WIFI_RESPONSE_PROMPT, now);
      }
      break;

    case WIFI_RESPONSE_PROMPT:
      if ((uint32_t)(now - state_tick) >= WIFI_COMMAND_TIMEOUT_MS)
      {
        board.log("\r\n[WiFi] CIPSEND prompt timeout; reset ESP if repeated.\r\n");
        wifi_retry("\r\n[WiFi] Missing CIPSEND result; restarting setup.\r\n", now);
      }
      break;

    case WIFI_RESPONSE_BODY:
      if (board.write((const uint8_t *)response_buffer, reply_length))
      {
        wifi_change_state(WIFI_RESPONSE_RESULT, now);
      }
      break;

    case WIFI_RESPONSE_RESULT:
      if ((uint32_t)(now - state_tick) >= WIFI_COMMAND_TIMEOUT_MS)
      {
        board.log("\r\n[WiFi] HTTP send timeout.\r\n");
        wifi_retry("\r\n[WiFi] Missing send result; restarting setup.\r\n", now);
      }
      break;

    case WIFI_CLOSE_SEND:
      length = snprintf(command_buffer, sizeof(command_buffer),
                        "AT+CIPCLOSE=%u\r\n", (unsigned int)response_link);
      if ((length > 0) && ((uint32_t)length < sizeof(command_buffer)) &&
          board.write((const uint8_t *)command_buffer, (uint16_t)length))
      {
        wifi_change_state(WIFI_CLOSE_WAIT, now);
      }
      break;

    case WIFI_CLOSE_WAIT:
      if ((uint32_t)(now - state_tick) >= WIFI_COMMAND_TIMEOUT_MS)
      {
        wifi_retry("\r\n[WiFi] Missing close result; restarting setup.\r\n", now);
      }
      break;

    case WIFI_RETRY_WAIT:
      if ((uint32_t)(now - state_tick) >= WIFI_RETRY_WAIT_MS)
      {
        restart_needed = true;
      }
      break;

    default:
      break;
  }
}
