/**
 * @file esp_at.c
 * @brief ESP8266 AT 传输层：识别文本应答、+IPD 数据和连接事件，以状态机串行发送。
 */
#include "esp_at.h"
#include "board_io.h"
#include <stdio.h>
#include <string.h>

/* 按普通传输、多连接和不附加远端信息的格式处理 AT 数据；具体固件兼容由应用初始化负责。 */
typedef enum { AT_IDLE, AT_REPLY, AT_PROMPT, AT_PAYLOAD, AT_SEND } at_state_t;
static at_state_t state;
static esp_data_fn on_data;
static esp_link_fn on_link;
static char line[240];
static size_t line_length;
static uint8_t payload[512];
static size_t payload_length;
static uint32_t started;
static uint32_t timeout;
static uint32_t ipd_started;
static uint32_t ipd_remaining;
static uint8_t ipd_link;
static int completion;
static int fault;
static int commands_started;
static uint8_t send_link;
/* 命令缓冲区由主循环独占，通过 esp_at_busy 保证命令串行执行。 */
static char command_buffer[240];

/**
 * @brief 注册数据与连接回调，清空 AT 状态和上次事务结果。
 */
void esp_at_init(esp_data_fn data_callback, esp_link_fn link_callback)
{
    on_data = data_callback;
    on_link = link_callback;
    state = AT_IDLE;
    line_length = 0U;
    ipd_remaining = 0U;
    completion = 0;
    fault = 0;
    commands_started = 0;
}

/**
 * @brief 结束当前 AT 事务并保存结果，等待上层调用 esp_at_result 消费。
 */
static void finish(int result)
{
    state = AT_IDLE;
    completion = result;
}

/**
 * @brief 命令执行中、结果尚未读取或串口仍在发送时返回非零。
 */
int esp_at_busy(void) { return state != AT_IDLE || completion != 0 || board_io_wifi_tx_busy(); }
/**
 * @brief 查询传输故障；出现故障后由上层复位网络并重新初始化。
 */
int esp_at_fault(void) { return fault; }
/**
 * @brief 取出并清除事务结果：0 等待或空闲，1 成功，-1 命令错误，-2 超时或故障。
 */
int esp_at_result(void) { int result = completion; completion = 0; return result; }

/**
 * @brief 追加回车换行并启动一条 AT 命令；timeout_ms 指定整个事务的超时时间。
 */
int esp_at_command(const char *command, uint32_t timeout_ms)
{
    int length;
    if (!command || esp_at_busy() || fault) { return 0; }
    length = snprintf(command_buffer, sizeof(command_buffer), "%s\r\n", command);
    if (length <= 0 || (size_t)length >= sizeof(command_buffer)) { return 0; }
    if (!board_io_wifi_send((const uint8_t *)command_buffer, (size_t)length)) { return 0; }
    started = board_io_now();
    timeout = timeout_ms;
    state = AT_REPLY;
    commands_started = 1;
    return 1;
}

/**
 * @brief 复制网络载荷并发送 CIPSEND；等待提示符后由处理函数发送实际数据。
 */
int esp_at_send(uint8_t link, const uint8_t *data, size_t length)
{
    char command[40];
    if (link >= 5U || !data || !length || length > sizeof(payload) || esp_at_busy() || fault) { return 0; }
    (void)snprintf(command, sizeof(command), "AT+CIPSEND=%u,%u", (unsigned)link, (unsigned)length);
    if (!esp_at_command(command, 5000U)) { return 0; }
    memcpy(payload, data, length);
    payload_length = length;
    send_link = link;
    state = AT_PROMPT;
    return 1;
}

/**
 * @brief 为编号 0～4 的 TCP 连接发起关闭命令。
 */
int esp_at_close(uint8_t link)
{
    char command[32];
    if (link >= 5U) { return 0; }
    (void)snprintf(command, sizeof(command), "AT+CIPCLOSE=%u", (unsigned)link);
    return esp_at_command(command, 3000U);
}

/**
 * @brief 解析完整文本行，区分连接通知、启动提示、命令完成和错误应答。
 */
static void parse_line(void)
{
    line[line_length] = '\0';
    if (line_length == 9U && line[0] >= '0' && line[0] <= '4' && strcmp(line + 1, ",CONNECT") == 0) {
        if (on_link) { on_link((uint8_t)(line[0] - '0'), 1); }
    } else if (line_length == 8U && line[0] >= '0' && line[0] <= '4' && strcmp(line + 1, ",CLOSED") == 0) {
        /* 连接断开时模块可能仍等待载荷；将状态标记为故障，交由上层复位，
           避免把旧数据或新 AT 命令误作为未完成 CIPSEND 的载荷。 */
        if ((state == AT_PROMPT || state == AT_PAYLOAD || state == AT_SEND) &&
            send_link == (uint8_t)(line[0] - '0')) { fault = 1; }
        if (on_link) { on_link((uint8_t)(line[0] - '0'), 0); }
    } else if (strcmp(line, "ready") == 0) {
        /* 首次命令前的 ready 属于正常启动；命令开始后的 ready 表示模块意外重启。 */
        if (commands_started) { fault = 1; }
    } else if (strcmp(line, "OK") == 0) {
        if (state == AT_REPLY) { finish(1); }
    } else if (strcmp(line, "SEND OK") == 0) {
        if (state == AT_SEND) { finish(1); }
    } else if (strcmp(line, "ERROR") == 0 || strcmp(line, "FAIL") == 0 || strcmp(line, "SEND FAIL") == 0 || strncmp(line, "busy", 4U) == 0) {
        if (state != AT_IDLE) { finish(-1); }
    } else if (strncmp(line, "AT version", 10U) == 0 || strncmp(line, "SDK version", 11U) == 0 || strncmp(line, "version:", 8U) == 0 || strncmp(line, "+CIFSR:", 7U) == 0) {
        board_io_log(line);
        board_io_log("\r\n");
    }
    line_length = 0U;
}

/**
 * @brief 解析 +IPD,<连接号>,<长度>:，记录后续应按原始数据处理的字节数。
 */
static int parse_ipd_header(void)
{
    size_t pos;
    uint32_t length = 0U;
    if (line_length < 9U || memcmp(line, "+IPD,", 5U) != 0) { return 0; }
    if (line[5] < '0' || line[5] > '4' || line[6] != ',') { fault = 1; return 0; }
    for (pos = 7U; pos + 1U < line_length; ++pos) {
        if (line[pos] < '0' || line[pos] > '9') { fault = 1; return 0; }
        length = length * 10U + (uint32_t)(line[pos] - '0');
        if (length > 65535U) { fault = 1; return 0; }
    }
    ipd_link = (uint8_t)(line[5] - '0');
    ipd_remaining = length;
    ipd_started = board_io_now();
    line_length = 0U;
    return 1;
}

/**
 * @brief 逐字节分离 AT 文本与 TCP 原始数据；原始数据中的换行和提示符不作为 AT 应答。
 */
static void receive_byte(uint8_t byte)
{
    if (ipd_remaining) {
        --ipd_remaining;
        if (on_data) { on_data(ipd_link, byte); }
        return;
    }
    if (byte == '>' && state == AT_PROMPT) { state = AT_PAYLOAD; line_length = 0U; return; }
    if (byte == '\r') { return; }
    if (byte == '\n') { parse_line(); return; }
    if (line_length == 0U && byte == ' ') { return; }
    if (line_length >= sizeof(line) - 1U) { fault = 1; return; }
    line[line_length++] = (char)byte;
    if (byte == ':' && line_length >= 5U && memcmp(line, "+IPD,", 5U) == 0) { (void)parse_ipd_header(); }
}

/**
 * @brief 主循环处理接收队列和发送阶段，每次限制处理预算，并检测数据与命令超时。
 */
void esp_at_process(void)
{
    uint8_t byte;
    unsigned budget = 4096U;
    if (board_io_wifi_fault()) { board_io_log("[AT] UART receive error/overflow\r\n"); fault = 1; }
    while (budget-- && !fault && board_io_wifi_read(&byte)) { receive_byte(byte); }
    if (!fault && state == AT_PAYLOAD && !board_io_wifi_tx_busy()) {
        if (board_io_wifi_send(payload, payload_length)) { state = AT_SEND; }
        else { fault = 1; }
    }
    if (ipd_remaining && (uint32_t)(board_io_now() - ipd_started) > 3000U) { fault = 1; }
    if (state != AT_IDLE && (uint32_t)(board_io_now() - started) > timeout) {
        board_io_log("[AT] command response timeout\r\n");
        fault = 1;
    }
    if (fault && state != AT_IDLE) { finish(-2); }
}
