"""Local MQTT 3.1.1 control panel; Python standard library only."""
import json
import queue
import socket
import threading
import time
import tkinter as tk
from tkinter import ttk

events = queue.Queue()
requests = queue.Queue()
stop = threading.Event()

def field(value):
    value = value.encode('utf-8')
    return len(value).to_bytes(2, 'big') + value

def packet(kind, body=b''):
    length = len(body)
    out = bytearray([kind])
    while True:
        part = length % 128
        length //= 128
        out.append(part | (128 if length else 0))
        if not length:
            return bytes(out) + body

def receive_frames(buffer):
    frames = []
    while len(buffer) >= 2:
        length = 0
        multiplier = 1
        end = None
        for index in range(1, min(5, len(buffer))):
            byte = buffer[index]
            length += (byte & 127) * multiplier
            if not byte & 128:
                end = index + 1
                break
            multiplier *= 128
        if end is None:
            if len(buffer) >= 5:
                raise ValueError('MQTT 长度字段错误')
            break
        if length > 512:
            raise ValueError('MQTT 数据包过大')
        if len(buffer) < end + length:
            break
        frames.append((buffer[0], bytes(buffer[end:end + length])))
        del buffer[:end + length]
    return frames

def network(host):
    sock = None
    connected = False
    try:
        sock = socket.create_connection((host, 1883), timeout=5)
        sock.settimeout(0.15)
        body = field('MQTT') + bytes([4, 2, 0, 30]) + field('guide-desktop')
        sock.sendall(packet(0x10, body))
        buffer = bytearray()
        started = last_tx = time.monotonic()
        last_rx = started
        while not stop.is_set():
            if not connected and time.monotonic() - started > 8:
                raise TimeoutError('等待 MQTT CONNACK 超时')
            if time.monotonic() - last_rx > 45:
                raise TimeoutError('设备响应超时')
            try:
                data = sock.recv(2048)
                if not data:
                    raise ConnectionError('开发板已断开连接')
                buffer.extend(data)
                for kind, body in receive_frames(buffer):
                    last_rx = time.monotonic()
                    if kind == 0x20:
                        if body != b'\x00\x00':
                            raise ConnectionError('MQTT 连接被拒绝: ' + body.hex())
                        connected = True
                        events.put(('status', '已连接，正在订阅状态'))
                        sock.sendall(packet(0x82, b'\x00\x01' + field('guide/#') + b'\x00'))
                        last_tx = time.monotonic()
                    elif kind == 0x90:
                        if body != b'\x00\x01\x00':
                            raise ConnectionError('订阅失败: ' + body.hex())
                        events.put(('status', '已连接：可控制 RGB 灯和蜂鸣器'))
                    elif kind >> 4 == 3:
                        if len(body) < 2:
                            raise ValueError('发布包无主题')
                        n = int.from_bytes(body[:2], 'big')
                        if n > len(body) - 2:
                            raise ValueError('发布包主题长度错误')
                        topic = body[2:2+n].decode('utf-8')
                        value = body[2+n:].decode('utf-8')
                        events.put(('message', topic + '  ' + value))
            except socket.timeout:
                pass
            if connected:
                try:
                    topic, value = requests.get_nowait()
                    sock.sendall(packet(0x30, field(topic) + value.encode('utf-8')))
                    last_tx = time.monotonic()
                except queue.Empty:
                    pass
                if time.monotonic() - last_tx >= 10:
                    sock.sendall(b'\xc0\x00')
                    last_tx = time.monotonic()
        if connected:
            sock.sendall(b'\xe0\x00')
    except (OSError, ValueError) as exc:
        events.put(('status', '连接结束：' + str(exc)))
    finally:
        if sock:
            sock.close()
        events.put(('finished', ''))

window = tk.Tk()
window.title('指南者 MQTT 板载控制')
window.geometry('760x530')
window.option_add('*Font', ('Microsoft YaHei UI', 10))
frame = ttk.Frame(window, padding=18)
frame.pack(fill='both', expand=True)
ttk.Label(frame, text='先让电脑连接开发板的 senyu Wi-Fi，再点击连接。').pack(anchor='w')
row = ttk.Frame(frame)
row.pack(fill='x', pady=12)
ttk.Label(row, text='服务器').pack(side='left')
address = tk.StringVar(value='192.168.4.1')
ttk.Entry(row, textvariable=address, width=20).pack(side='left', padx=8)
worker = None
status = tk.StringVar(value='未连接')

def connect():
    global worker
    if worker and worker.is_alive():
        return
    while not requests.empty():
        requests.get_nowait()
    stop.clear()
    status.set('连接中…')
    worker = threading.Thread(target=network, args=(address.get().strip(),), daemon=True)
    worker.start()

def send(topic, value):
    if not worker or not worker.is_alive():
        status.set('请先连接开发板')
        return
    requests.put((topic, value))

ttk.Button(row, text='连接', command=connect).pack(side='left')
ttk.Button(row, text='断开', command=stop.set).pack(side='left', padx=8)
ttk.Label(frame, textvariable=status).pack(anchor='w')
colors = ttk.LabelFrame(frame, text='RGB 灯', padding=10)
colors.pack(fill='x', pady=14)
for index, (label, value) in enumerate([('红','red'),('绿','green'),('蓝','blue'),('黄','yellow'),('青','cyan'),('紫','magenta'),('白','white'),('关灯','off')]):
    ttk.Button(colors, text=label, command=lambda v=value: send('guide/rgb', v)).grid(row=index//4, column=index%4, padx=7, pady=5, sticky='ew')
    colors.columnconfigure(index%4, weight=1)
beeps = ttk.Frame(frame)
beeps.pack(fill='x')
ttk.Button(beeps, text='短鸣 100ms', command=lambda: send('guide/beep','100')).pack(side='left')
ttk.Button(beeps, text='短鸣 500ms', command=lambda: send('guide/beep','500')).pack(side='left', padx=8)
ttk.Button(beeps, text='静音', command=lambda: send('guide/beep','off')).pack(side='left')
log = tk.Text(frame, height=10, wrap='word', state='disabled')
log.pack(fill='both', expand=True, pady=(15,0))

def poll():
    while not events.empty():
        kind, value = events.get_nowait()
        if kind == 'status':
            status.set(value)
        elif kind == 'message':
            log.configure(state='normal')
            log.insert('end', value + '\n')
            if int(log.index('end-1c').split('.')[0]) > 150:
                log.delete('1.0', '25.0')
            log.see('end')
            log.configure(state='disabled')
    window.after(100, poll)

def close():
    stop.set()
    window.destroy()

window.protocol('WM_DELETE_WINDOW', close)
poll()
window.mainloop()
