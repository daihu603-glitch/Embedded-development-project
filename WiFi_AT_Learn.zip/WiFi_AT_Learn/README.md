# WiFi_AT_Learn：手机网页控制 LED2

## 手机操作

1. CubeIDE 点击红色方块 Terminate，结束旧调试。
2. 选中 WiFi_AT_Learn，按 F5 刷新，Project → Build Project。
3. 用已有 WiFi_AT_Learn Debug 配置下载：SEGGER J-LINK / SWD / 1000 kHz。
4. 停在 main 时点击 Resume（F8）运行，等待约 5～15 秒。
5. 手机连接热点 STM32_LED，密码 12345678；提示无互联网时选择保持连接。
6. 浏览器地址栏输入 http://192.168.4.1，点击“开灯”或“关灯”。

LED1（PA8）继续每 500 ms 翻转，LED2（PB15）由网页控制，初始化为关闭。

旧版 AT 初始化兼容：先停止服务器、关闭残留连接、切回单连接模式，
再设置普通传输模式，最后重新启用多连接服务器。避免仅重启 STM32 时
ESP8266 保留 `CIPMUX=1`，导致 `CIPMODE=0` 报错并循环重试。

连续操作修复：收到 `CLOSED` 后，等待当前 AT 命令的最终 `OK/ERROR`
再处理下一请求，避免旧结果影响新请求；对端已关闭时不再重复发关闭命令。
如果最终结果超时，重新初始化 WiFi 服务。主机回归测试覆盖 100 次连续开关、
连接编号复用以及分开到达的关闭通知和命令结果；仍需重新下载后实物验证。
根据用户报告的实物亮灭相反现象，LED2 改为低电平点亮：
board_wifi.c 的 BOARD_LED2_ON_LEVEL 为 GPIO_PIN_RESET。
网页“开灯”输出低电平，“关灯”输出高电平，需下载后确认实际效果。

## 串口日志

免安装工具：桌面“AT串口助手”或本项目 Open-Serial-Helper.cmd。
用户确认底板 CH340K 为 COM7（重新插拔后可能变化）。参数为 115200 / 8N1 / 无流控。
保持端口打开，按核心板 RST，可看到启动、AT 指令及模块返回。
成功时应看到：

```
[READY] SSID: STM32_LED | Password: 12345678
[READY] Open http://192.168.4.1 | LED2=PB15
```

电脑可发送 status 查询初始化状态。
新版由 STM32 自动配置 ESP8266，UART2 由网页服务独占；电脑发送的 AT 不再透传。
原透传版 main.c 已备份到 tools/backups/main-serial-bridge.c.txt，
原说明在 tools/backups/README-serial-bridge.md。

## 接线

| 功能 | STM32 引脚 |
|---|---|
| LED1 / LED2 | PA8 / PB15 |
| USART1 TX / RX（电脑） | PA9 / PA10 |
| USART2 TX / RX（WiFi） | PA2 / PA3 |
| SWDIO / SWCLK（J-Link） | PA13 / PA14 |

H3 按提供的原理图连接 3—5、4—6，以实物 IOT / USART2 / WIFI 标签和 1 脚标记确认。
每个跳帽连接 USART2 与 WIFI；按本次照片方向是同一列“中排＋下排”。调整前断电。
BOOT0 保持 0。开发板另行供电，J-Link VTref 接 3.3V，GND 共地。

## 文件与学习位置

| 文件 | 作用 |
|---|---|
| Core/Src/main.c | CubeMX 初始化后调用 board_wifi_init / board_wifi_process |
| Core/Src/board_wifi.c | HAL 适配、串口中断缓存、非阻塞发送、日志、LED |
| Core/Src/wifi_web.c | 独立于 HAL 的 AT 状态机、IPD 解析、HTTP 和网页 |
| Core/Inc/wifi_web.h | 模块 API 和硬件接口契约 |
| Core/Src/usart.c、gpio.c | CubeMX 生成的初始化，未修改 |
| tests/test_wifi_web.c | 电脑上模拟模块响应和手机请求的测试 |

main.c 修改仅在 USER CODE 区域；保留既有 Core / Drivers 目录和 CubeMX 初始化。
新增源文件放在 Core/Src，CubeIDE 刷新后自动参与编译。
接收中断只缓存字节，主循环解析并启动异步发送。
每个 HTTP 连接独立保存请求状态，支持跨多个 IPD 帧的分包数据。

## AT 固件与命令

用户读取到 AT 1.2.0.0 / SDK 1.5.4.1，Ai-Thinker，2016 年版本。
程序顺序发送：

```
AT
ATE0
AT+CIPSERVER=0
AT+CIPMODE=0
AT+CWMODE_CUR=2
AT+CWSAP_CUR="STM32_LED","12345678",6,3
AT+CIPAP_CUR="192.168.4.1","192.168.4.1","255.255.255.0"
AT+CWDHCP_CUR=0,1
AT+CIPMUX=1
AT+CIPDINFO=0
AT+CIPSERVER=1,80
AT+CIPSTO=15
```

删除旧服务允许 ERROR（例如服务尚未存在）；其他配置要求 OK，失败会输出日志并重试。
_CUR 配置不写入 Flash，每次运行重新配置；没有刷写 ESP8266 固件。
收到 +IPD,<连接号>,<长度>:<数据> 后，解析 HTTP 请求。
发送 AT+CIPSEND，等待 >，发送完整 HTTP 响应，收到 SEND OK 后关闭连接。
网页路径 / 显示状态，/on 开灯，/off 关灯；其他路径返回 404。

依据：[Espressif ESP8266 AT Instruction Set v1.5.4（2016-05-13）](https://www.espressif.com/sites/default/files/4a-esp8266_at_instruction_set_en_v1.5.4_0.pdf)。

## 验证

- 用户已实测旧透传版：LED1 闪烁、COM7 收到 AT 的 OK 和上述版本信息。
- 新网页版使用 CubeIDE 2.2.0 的 ARM GCC 14.3 编译和链接通过，无编译警告或错误。
- 最终 Debug/WiFi_AT_Learn.elf：text 18268 + data 2196 = 20464 字节 Flash；
  data 2196 + bss 8708 = 10904 字节静态 RAM，堆栈预留另计，未超出 F103C8 容量。
- 七组协议测试通过：分包与 HTTP 字节长度、非法连接与路径、多连接及发送缓冲区、
  过长请求、时钟回绕与初始化重试、不完整请求与溢出、截断 IPD 的超时恢复。
- 新版尚未下载到实际开发板；热点、网页和 LED2 实际亮灭待用户验证。

最终编译日志：build-web-final.log；测试记录：tests/test-results.log。
初次完整构建日志 build-web.log 中前置清理有一条被忽略的工具错误，后续编译链接成功；
最终增量构建再次通过。

## 排查

- LED1 不闪：确认 Resume，且程序没有停在断点。
- 没有热点：查看串口日志停在哪条 AT 指令。
- AT 超时：检查 H3、供电、波特率；避免在通信时暂停调试。
- 连上但打不开网页：保持该 WiFi，地址明确使用 http://192.168.4.1。
- 反复 CIPSEND 超时：按 ESP8266 RESET，程序检测到 ready 后会重新初始化。
