/**
 * @file mqtt_endpoint.c
 * @brief 本地 MQTT 服务端：维护有限个客户端和订阅，执行控制命令并转发匹配主题。
 */
#include "mqtt_endpoint.h"
#include "mqtt_codec.h"
#include <string.h>

#define SUBSCRIPTION_COUNT 4U
#define TOPIC_CAPACITY 80U
#define CLIENT_ID_CAPACITY 64U
#define COMMAND_CAPACITY 96U

typedef struct {
    mqtt_stream_t stream;
    uint8_t open;
    uint8_t connected;
    uint16_t keepalive;
    uint32_t last_packet;
    uint32_t fragment_started;
    char id[CLIENT_ID_CAPACITY];
    char subscriptions[SUBSCRIPTION_COUNT][TOPIC_CAPACITY];
} client_t;

static client_t clients[MQTT_CLIENTS];
static mqtt_send_fn send_packet;
static mqtt_close_fn close_link;
static mqtt_command_fn on_command;
static uint8_t outgoing[MQTT_PACKET_CAPACITY];
static uint32_t command_count;

/**
 * @brief 将会话标记为断开，并通过回调申请关闭底层 TCP 连接。
 */
static void disconnect(uint8_t link)
{
    clients[link].open = 0U;
    clients[link].connected = 0U;
    if (close_link) { close_link(link); }
}

/**
 * @brief 经上层队列发送 MQTT 报文；无法入队时断开该客户端。
 */
static int send_to(uint8_t link, const uint8_t *packet, size_t length)
{
    if (!send_packet || !send_packet(link, packet, length)) { disconnect(link); return 0; }
    return 1;
}

/**
 * @brief 清空客户端和命令计数，注册发送、关闭连接及业务命令回调。
 */
void mqtt_endpoint_init(mqtt_send_fn send, mqtt_close_fn close, mqtt_command_fn command)
{
    memset(clients, 0, sizeof(clients));
    send_packet = send;
    close_link = close;
    on_command = command;
    command_count = 0U;
}

/**
 * @brief TCP 连接建立时清空对应槽位，并开始等待客户端 CONNECT 报文。
 */
void mqtt_endpoint_open(uint8_t link, uint32_t now)
{
    if (link >= MQTT_CLIENTS) { return; }
    memset(&clients[link], 0, sizeof(clients[link]));
    clients[link].open = 1U;
    clients[link].last_packet = now;
}

/**
 * @brief TCP 连接断开后释放该槽位的会话、订阅和组包状态。
 */
void mqtt_endpoint_closed(uint8_t link)
{
    if (link < MQTT_CLIENTS) { memset(&clients[link], 0, sizeof(clients[link])); }
}

/* 本地服务的主题和客户端标识限定为有长度上限的可打印 ASCII 字符串。 */
/**
 * @brief 读取带双字节长度的字符串；当前服务限定为可打印 ASCII，并校验输出容量。
 */
static int read_string(const uint8_t *body, size_t length, size_t *offset, char *out, size_t capacity)
{
    size_t count;
    size_t i;
    if (*offset > length || length - *offset < 2U) { return 0; }
    count = ((size_t)body[*offset] << 8) | body[*offset + 1U];
    *offset += 2U;
    if (count >= capacity || count > length - *offset) { return 0; }
    for (i = 0U; i < count; ++i) {
        if (body[*offset + i] < 32U || body[*offset + i] > 126U) { return 0; }
        out[i] = (char)body[*offset + i];
    }
    out[count] = '\0';
    *offset += count;
    return 1;
}

/**
 * @brief 校验 MQTT 3.1.1 和连接选项，回复 CONNACK；相同 Client ID 的旧会话会被断开。
 */
static void handle_connect(uint8_t link, const uint8_t *body, size_t length)
{
    uint8_t reply[4] = {0x20U, 2U, 0U, 0U};
    size_t offset = 10U;
    unsigned i;
    client_t *client = &clients[link];
    if (client->connected || length < 12U || memcmp(body, "\0\4MQTT", 6U) != 0) { disconnect(link); return; }
    if (body[6] != 4U) { reply[3] = 1U; }
    /* 本地服务只接受清理会话，不接受遗嘱、用户名或密码字段。 */
    else if (body[7] != 2U) { reply[3] = 5U; }
    else if (!read_string(body, length, &offset, client->id, sizeof(client->id)) || !client->id[0] || offset != length) { reply[3] = 2U; }
    if (reply[3]) {
        (void)send_to(link, reply, sizeof(reply));
        disconnect(link);
        return;
    }
    for (i = 0U; i < MQTT_CLIENTS; ++i) {
        if (i != link && clients[i].connected && strcmp(clients[i].id, client->id) == 0) { disconnect((uint8_t)i); }
    }
    client->keepalive = (uint16_t)(((uint16_t)body[8] << 8) | body[9]);
    client->connected = 1U;
    (void)send_to(link, reply, sizeof(reply));
}

/**
 * @brief 校验订阅过滤器：# 只能占据最后一级，+ 必须单独占据一级。
 */
static int filter_valid(const char *filter)
{
    size_t i;
    if (!filter[0]) { return 0; }
    for (i = 0U; filter[i]; ++i) {
        if (filter[i] == '#' && ((i && filter[i - 1U] != '/') || filter[i + 1U])) { return 0; }
        if (filter[i] == '+' && ((i && filter[i - 1U] != '/') || (filter[i + 1U] && filter[i + 1U] != '/'))) { return 0; }
    }
    return 1;
}

/**
 * @brief 逐层匹配订阅过滤器和主题，支持 + 与 #，并遵守 $ 主题的通配匹配限制。
 */
static int topic_matches(const char *filter, const char *topic)
{
    const char *f = filter;
    const char *t = topic;
    if (*t == '$' && (*f == '#' || *f == '+')) { return 0; }
    for (;;) {
        if (*f == '#') { return 1; }
        if (*f == '+') { while (*t && *t != '/') { ++t; } ++f; }
        else { while (*f && *f != '/' && *t && *t != '/') { if (*f++ != *t++) { return 0; } } }
        if (!*f && !*t) { return 1; }
        if (!*t && strcmp(f, "/#") == 0) { return 1; }
        if (*f != '/' || *t != '/') { return 0; }
        ++f;
        ++t;
    }
}

/**
 * @brief 优先返回已有订阅位置，否则返回第一个空槽；无可用槽返回 -1。
 */
static int subscription_slot(client_t *client, const char *topic)
{
    unsigned i;
    int empty = -1;
    for (i = 0U; i < SUBSCRIPTION_COUNT; ++i) {
        if (strcmp(client->subscriptions[i], topic) == 0) { return (int)i; }
        if (!client->subscriptions[i][0] && empty < 0) { empty = (int)i; }
    }
    return empty;
}

/**
 * @brief 处理订阅或取消订阅，并按报文标识符回复 SUBACK 或 UNSUBACK。
 */
static void handle_subscribe(uint8_t link, const uint8_t *body, size_t length, int unsubscribe)
{
    size_t offset = 2U;
    size_t count = 0U;
    uint8_t reply[4U + SUBSCRIPTION_COUNT];
    char topic[TOPIC_CAPACITY];
    int slot;
    unsigned i;
    if (length < 5U || (!body[0] && !body[1])) { disconnect(link); return; }
    reply[0] = unsubscribe ? 0xB0U : 0x90U;
    reply[2] = body[0];
    reply[3] = body[1];
    while (offset < length) {
        if (count >= SUBSCRIPTION_COUNT || !read_string(body, length, &offset, topic, sizeof(topic)) || !filter_valid(topic)) { disconnect(link); return; }
        if (unsubscribe) {
            for (i = 0U; i < SUBSCRIPTION_COUNT; ++i) {
                if (strcmp(clients[link].subscriptions[i], topic) == 0) { clients[link].subscriptions[i][0] = '\0'; }
            }
        } else {
            if (offset >= length || body[offset++] > 2U) { disconnect(link); return; }
            slot = subscription_slot(&clients[link], topic);
            reply[4U + count] = slot >= 0 ? 0U : 0x80U;
            if (slot >= 0) { strcpy(clients[link].subscriptions[slot], topic); }
        }
        ++count;
    }
    if (!count) { disconnect(link); return; }
    reply[1] = unsubscribe ? 2U : (uint8_t)(2U + count);
    (void)send_to(link, reply, unsubscribe ? 4U : 4U + count);
}

/**
 * @brief 生成无保留的 QoS0 消息，向所有匹配订阅的已连接客户端各发送一次。
 */
void mqtt_endpoint_publish(const char *topic, const char *payload)
{
    unsigned i;
    unsigned sub;
    size_t length = mqtt_publish(outgoing, sizeof(outgoing), topic, payload, 0);
    if (!length) { return; }
    for (i = 0U; i < MQTT_CLIENTS; ++i) {
        if (!clients[i].connected) { continue; }
        for (sub = 0U; sub < SUBSCRIPTION_COUNT; ++sub) {
            if (clients[i].subscriptions[sub][0] && topic_matches(clients[i].subscriptions[sub], topic)) {
                (void)send_to((uint8_t)i, outgoing, length);
                break;
            }
        }
    }
}

/**
 * @brief 校验 QoS0、非保留和 ASCII 载荷后调用业务回调，再将消息转发给订阅者。
 */
static void handle_publish(uint8_t link, const uint8_t *packet, size_t length)
{
    mqtt_publish_t message;
    char topic[TOPIC_CAPACITY];
    char payload[COMMAND_CAPACITY];
    size_t i;
    if (!mqtt_read_publish(packet, length, &message) || message.qos || message.retained) { disconnect(link); return; }
    if (message.topic_length >= sizeof(topic) || message.payload_length >= sizeof(payload)) { disconnect(link); return; }
    for (i = 0U; i < message.topic_length; ++i) {
        uint8_t c = message.topic[i];
        if (c < 32U || c > 126U || c == '+' || c == '#') { disconnect(link); return; }
    }
    for (i = 0U; i < message.payload_length; ++i) {
        if (message.payload[i] < 32U || message.payload[i] > 126U) { disconnect(link); return; }
    }
    memcpy(topic, message.topic, message.topic_length);
    topic[message.topic_length] = '\0';
    memcpy(payload, message.payload, message.payload_length);
    payload[message.payload_length] = '\0';
    ++command_count;
    if (on_command) { on_command(topic, payload); }
    mqtt_endpoint_publish(topic, payload);
}

/**
 * @brief 按固定头分发连接、发布、订阅、取消订阅、心跳和断开报文。
 */
static void handle_packet(uint8_t link)
{
    client_t *client = &clients[link];
    const uint8_t *packet = client->stream.bytes;
    const uint8_t *body;
    size_t length;
    const uint8_t pong[2] = {0xD0U, 0U};
    if (!mqtt_packet_body(packet, client->stream.length, &body, &length)) { disconnect(link); return; }
    if (packet[0] == 0x10U) { handle_connect(link, body, length); return; }
    if (!client->connected) { disconnect(link); return; }
    switch (packet[0]) {
    case 0x30U: handle_publish(link, packet, client->stream.length); break;
    case 0x82U: handle_subscribe(link, body, length, 0); break;
    case 0xA2U: handle_subscribe(link, body, length, 1); break;
    case 0xC0U:
        if (length) { disconnect(link); break; }
        (void)send_to(link, pong, sizeof(pong));
        break;
    case 0xE0U: disconnect(link); break;
    default: disconnect(link); break;
    }
}

/**
 * @brief 按连接逐字节组包；收齐后处理并重置组包器，非法报文触发断开。
 */
void mqtt_endpoint_feed(uint8_t link, uint8_t byte, uint32_t now)
{
    int result;
    client_t *client;
    if (link >= MQTT_CLIENTS || !clients[link].open) { return; }
    client = &clients[link];
    if (!client->stream.length) { client->fragment_started = now; }
    result = mqtt_stream_feed(&client->stream, byte);
    if (result < 0) { disconnect(link); return; }
    if (result > 0) {
        client->last_packet = now;
        handle_packet(link);
        mqtt_stream_reset(&client->stream);
    }
}

/**
 * @brief 检查超时：CONNECT 等待 10 秒、分包等待 5 秒、心跳等待 Keep Alive 的 1.5 倍。
 */
void mqtt_endpoint_process(uint32_t now)
{
    unsigned i;
    for (i = 0U; i < MQTT_CLIENTS; ++i) {
        client_t *client = &clients[i];
        uint32_t limit = client->connected ? (uint32_t)client->keepalive * 1500U : 10000U;
        if (!client->open) { continue; }
        if ((limit && (uint32_t)(now - client->last_packet) > limit) ||
            (client->stream.length && (uint32_t)(now - client->fragment_started) > 5000U)) { disconnect((uint8_t)i); }
    }
}

/**
 * @brief 统计完成 MQTT CONNECT 握手的客户端数量。
 */
unsigned mqtt_endpoint_clients(void)
{
    unsigned i;
    unsigned count = 0U;
    for (i = 0U; i < MQTT_CLIENTS; ++i) { if (clients[i].connected) { ++count; } }
    return count;
}

/**
 * @brief 返回本次服务初始化以来通过校验的发布消息数量。
 */
uint32_t mqtt_endpoint_command_count(void) { return command_count; }
