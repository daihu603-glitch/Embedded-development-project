# WiFi_AT_Learn 入门实验

目标：先验证 STM32 程序、电脑串口和 ESP8266 AT 通信，再学习联网。

## 已实现

- LED1（PA8）每 500 ms 翻转一次，完整亮灭周期约 1 秒。
- USART1（PA9 TX / PA10 RX）与 USART2（PA2 TX / PA3 RX）双向原样转发。
- LED2（PB15）在主循环检测到 WiFi 接收活动时翻转；快速通信时肉眼未必能看到每次变化。
- 两个串口均为 115200、8 数据位、无校验、1 停止位、无硬件流控。
- 接收中断只存数据，主循环启动非阻塞发送，不在接收中断中等待发送。
- 每个方向有 511 字节可用接收缓存，适用于短 AT 指令及响应。

代码修改仅在 `Core/Src/main.c` 的 USER CODE 区域。
USART/GPIO/时钟初始化仍由 CubeMX 管理，使用内部 HSI 倍频至 64 MHz。

## 板上连接（依据本次提供的原理图）

断电后，在 H3「NB-IOT/WIFI 通道选择」处用两个跳帽分别连接：

| 跳帽 | 连接关系 |
|---|---|
| H3 的 3 与 5 | STM32 PA2 TX → ESP8266 RX |
| H3 的 4 与 6 | ESP8266 TX → STM32 PA3 RX |

以板上的 1 脚标记和原理图确定编号；这两个跳帽不是每行左右短接。
USART1 对应底板 CH340 USB 转串口。BOOT0 保持 0，让 STM32 从 Flash 启动。
J-Link 用 SWD 连接 PA13、PA14、GND、VTref（板上 3.3V），可加 NRST；开发板另行供电。

## 编译与测试

1. CubeIDE 选中工程，按 F5 刷新，然后 Project → Build Project。
2. Run → Debug Configurations → Debugger，选择 SEGGER J-LINK 和 SWD。
3. 下载调试后按 Resume（继续），让程序运行；停在断点时主循环不会转发数据。
4. 用底板 CH340 对应的 USB 接口连接电脑，在串口助手打开其 COM 口。
5. 设置 115200 / 8N1 / 无流控。打开串口后按 STM32 的 RST，应收到 ready 提示。
6. 发送 `AT`，结尾选择 CR+LF（回车换行，即 `AT\r\n`）。
7. 若返回 `OK`，发送 `AT+GMR` 并保存版本信息，再开展联网实验。

这份程序不自动写入 WiFi 名称和密码，也不自动修改 ESP8266 固件。
透传保留原始字节，不自动追加换行。ESP8266 必须有 AT 固件，且实际波特率需匹配。
若有 ready 提示而没有 OK，依次确认 H3 跳帽、ESP8266 供电/正常启动、固件和波特率。

## CubeIDE 学习位置

- `main()`：初始化、启动接收、主循环。
- `HAL_UART_RxCpltCallback()`：接收一个字节后入队，再启动下一字节接收。
- `bridge_process()`：缓存数据转发到另一个串口；发送完成前保持发送缓冲区不变。
- `HAL_UART_ErrorCallback()`：记录串口错误，并在接收停止时重新启动。

在 Expressions 中可观察 `pc_to_wifi` 与 `wifi_to_pc` 的 `received`、`dropped`、
`uart_errors`、`rx_start_errors`、`tx_start_errors`。正常短指令测试时错误/丢弃计数应为 0。
调试暂停可能导致串口溢出；这一实验不是持续高速数据流的性能保证。

## 本次验证

已使用 CubeIDE 2.2.0 自带的 ARM GCC 14.3 工具链完成 Debug 编译和链接，
生成 `Debug/WiFi_AT_Learn.elf`，编译日志中没有警告或错误。
Flash 占用为 text 9832 + data 1172 = 11004 字节；静态 RAM 占用为 data 1172 + bss 1724 = 2896 字节，
不含链接脚本预留的堆栈区域。
受限执行环境中最初的 IDE 构建无法启动 make，之后直接运行同一工具链完成构建；
有效结果见 `build-direct.log`，早期失败记录保存在 `build-check.log`。
尚未下载到开发板；物理 LED、串口和 WiFi 响应仍需实际测试。
