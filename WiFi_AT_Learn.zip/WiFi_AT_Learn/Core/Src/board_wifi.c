#include "board_wifi.h"
#include "wifi_web.h"
#include "main.h"
#include "usart.h"

#include <stddef.h>
#include <string.h>

/* Board/HAL boundary. HAL declarations are from this project's UART/GPIO headers. */
#define BOARD_RX_CAPACITY 1024U
#define BOARD_LOG_CAPACITY 2048U
#define BOARD_LOG_CHUNK 128U
#define BOARD_HEARTBEAT_MS 500U
/* User reports reversed physical on/off behavior: LED2 is active-low. */
#define BOARD_LED2_ON_LEVEL GPIO_PIN_RESET

typedef struct
{
  UART_HandleTypeDef *uart;
  uint8_t byte;
  uint8_t data[BOARD_RX_CAPACITY];
  volatile uint16_t head;
  volatile uint16_t tail;
  volatile uint32_t received;
  volatile uint32_t dropped;
  volatile uint32_t errors;
  volatile uint32_t arm_errors;
} board_rx_t;

static board_rx_t pc_rx = {.uart = &huart1};
static board_rx_t wifi_rx = {.uart = &huart2};
static uint8_t log_ring[BOARD_LOG_CAPACITY];
static uint8_t log_tx[BOARD_LOG_CHUNK];
static uint16_t log_head;
static uint16_t log_tail;
static uint32_t log_dropped;
static uint32_t previous_wifi_dropped;
static uint32_t heartbeat_tick;
static char pc_command[64];
static uint16_t pc_command_length;

static void board_arm_rx(board_rx_t *port)
{
  if (HAL_UART_Receive_IT(port->uart, &port->byte, 1U) != HAL_OK)
  {
    port->arm_errors++;
  }
}

static board_rx_t *board_find_rx(UART_HandleTypeDef *uart)
{
  if (uart == &huart1)
  {
    return &pc_rx;
  }
  if (uart == &huart2)
  {
    return &wifi_rx;
  }
  return NULL;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart)
{
  board_rx_t *port = board_find_rx(uart);
  uint16_t next;
  if (port == NULL)
  {
    return;
  }
  next = (uint16_t)((port->head + 1U) % BOARD_RX_CAPACITY);
  port->received++;
  if (next != port->tail)
  {
    port->data[port->head] = port->byte;
    __DMB();
    port->head = next;
  }
  else
  {
    port->dropped++;
  }
  board_arm_rx(port);
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *uart)
{
  board_rx_t *port = board_find_rx(uart);
  if (port != NULL)
  {
    port->errors++;
    if (uart->RxState == HAL_UART_STATE_READY)
    {
      board_arm_rx(port);
    }
  }
}

static bool board_pop_rx(board_rx_t *port, uint8_t *byte)
{
  uint16_t head = port->head;
  if (head == port->tail)
  {
    return false;
  }
  __DMB();
  *byte = port->data[port->tail];
  __DMB();
  port->tail = (uint16_t)((port->tail + 1U) % BOARD_RX_CAPACITY);
  return true;
}

/* Logging never waits for the PC UART, and is never called from an ISR. */
static void board_log_byte(uint8_t byte)
{
  uint16_t next = (uint16_t)((log_head + 1U) % BOARD_LOG_CAPACITY);
  if (next == log_tail)
  {
    log_dropped++;
    return;
  }
  log_ring[log_head] = byte;
  log_head = next;
}

static void board_log(const char *text)
{
  while (*text != '\0')
  {
    board_log_byte((uint8_t)*text++);
  }
}

static void board_flush_log(void)
{
  uint16_t cursor = log_tail;
  uint16_t count = 0U;
  if (huart1.gState != HAL_UART_STATE_READY)
  {
    return;
  }
  while ((cursor != log_head) && (count < BOARD_LOG_CHUNK))
  {
    log_tx[count++] = log_ring[cursor];
    cursor = (uint16_t)((cursor + 1U) % BOARD_LOG_CAPACITY);
  }
  if ((count != 0U) && (HAL_UART_Transmit_IT(&huart1, log_tx, count) == HAL_OK))
  {
    log_tail = cursor;
  }
}

static bool board_wifi_tx_ready(void)
{
  return huart2.gState == HAL_UART_STATE_READY;
}

static bool board_wifi_write(const uint8_t *data, uint16_t length)
{
  return HAL_UART_Transmit_IT(&huart2, data, length) == HAL_OK;
}

static void board_set_led2(bool on)
{
  GPIO_PinState off = (BOARD_LED2_ON_LEVEL == GPIO_PIN_SET) ?
                      GPIO_PIN_RESET : GPIO_PIN_SET;
  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, on ? BOARD_LED2_ON_LEVEL : off);
}

static void board_pc_input(uint8_t byte)
{
  if (byte == '\n')
  {
    pc_command[pc_command_length] = '\0';
    if (strcmp(pc_command, "status") == 0)
    {
      board_log(wifi_web_is_ready() ?
        "\r\n[READY] STM32_LED / 12345678 / http://192.168.4.1\r\n" :
        "\r\n[WiFi] Setup in progress. See AT command log.\r\n");
    }
    else if (pc_command_length != 0U)
    {
      board_log("\r\n[INFO] Web mode owns ESP UART. Use phone buttons; PC command: status\r\n");
    }
    pc_command_length = 0U;
  }
  else if ((byte != '\r') && (pc_command_length < sizeof(pc_command) - 1U))
  {
    pc_command[pc_command_length++] = (char)byte;
  }
}

void board_wifi_init(void)
{
  static const wifi_web_io_t io =
  {
    .tx_ready = board_wifi_tx_ready,
    .write = board_wifi_write,
    .set_led = board_set_led2,
    .log = board_log
  };
  heartbeat_tick = HAL_GetTick();
  board_log("\r\nWiFi_AT_Learn: phone web LED2 control, 115200 8N1\r\n");
  board_arm_rx(&pc_rx);
  board_arm_rx(&wifi_rx);
  wifi_web_init(&io, heartbeat_tick);
}

void board_wifi_process(void)
{
  uint8_t byte;
  uint16_t budget;
  uint32_t now = HAL_GetTick();
  if (pc_rx.uart->RxState == HAL_UART_STATE_READY)
  {
    board_arm_rx(&pc_rx);
  }
  if (wifi_rx.uart->RxState == HAL_UART_STATE_READY)
  {
    board_arm_rx(&wifi_rx);
  }
  if (wifi_rx.dropped != previous_wifi_dropped)
  {
    previous_wifi_dropped = wifi_rx.dropped;
    wifi_web_rx_lost();
    board_log("\r\n[ERROR] WiFi RX overflow. Avoid pausing during communication.\r\n");
  }
  for (budget = 0U; (budget < BOARD_RX_CAPACITY) && board_pop_rx(&wifi_rx, &byte); budget++)
  {
    board_log_byte(byte);
    wifi_web_feed(byte, now);
  }
  for (budget = 0U; (budget < 64U) && board_pop_rx(&pc_rx, &byte); budget++)
  {
    board_pc_input(byte);
  }
  wifi_web_process(now);
  board_flush_log();
  if ((uint32_t)(now - heartbeat_tick) >= BOARD_HEARTBEAT_MS)
  {
    heartbeat_tick = now;
    HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
  }
}
