/**
 * @file board_io.c
 * @brief 板级接口：封装串口中断收发、ESP8266 复位、RGB 灯和蜂鸣器的 HAL 操作。
 */
#include "board_io.h"
#include "main.h"
#include "usart.h"
#include <string.h>

/* 串口 HAL 接口依据 FW_F1 V1.8.7 的 stm32f1xx_hal_uart.h。 */
#define WIFI_RING_SIZE 4096U
#define CONSOLE_RING_SIZE 256U
#define TX_CAPACITY 600U

typedef struct {
    volatile uint16_t head;
    volatile uint16_t tail;
    uint16_t capacity;
    uint8_t *data;
} byte_ring_t;

static uint8_t wifi_storage[WIFI_RING_SIZE];
static uint8_t console_storage[CONSOLE_RING_SIZE];
static byte_ring_t wifi_ring = {0U, 0U, WIFI_RING_SIZE, wifi_storage};
static byte_ring_t console_ring = {0U, 0U, CONSOLE_RING_SIZE, console_storage};
static uint8_t wifi_rx_byte;
static uint8_t console_rx_byte;
static uint8_t wifi_tx[TX_CAPACITY];
static volatile uint8_t tx_busy;
static volatile uint8_t wifi_error;
static volatile uint8_t console_error;
static uint8_t rgb_mask;
static uint8_t beep_active;
static uint32_t beep_started;
static uint32_t beep_duration;

/**
 * @brief 中断侧写入一个字节；队列满返回 0，内存屏障保证先写数据再公布写入位置。
 */
static int ring_push(byte_ring_t *ring, uint8_t byte)
{
    uint16_t next = (uint16_t)((ring->head + 1U) % ring->capacity);
    if (next == ring->tail) { return 0; }
    ring->data[ring->head] = byte;
    __DMB();
    ring->head = next;
    return 1;
}

/**
 * @brief 主循环侧取出一个字节；队列空或输出指针无效返回 0。
 */
static int ring_pop(byte_ring_t *ring, uint8_t *byte)
{
    if (byte == NULL || ring->head == ring->tail) { return 0; }
    *byte = ring->data[ring->tail];
    __DMB();
    ring->tail = (uint16_t)((ring->tail + 1U) % ring->capacity);
    return 1;
}

/**
 * @brief 关闭灯和蜂鸣器、使能 ESP8266，并开启 USART1 调试串口及 USART3 Wi-Fi 接收中断。
 */
int board_io_init(void)
{
    board_io_rgb(0U);
    board_io_beep(0U);
    HAL_GPIO_WritePin(ESP_EN_GPIO_Port, ESP_EN_Pin, GPIO_PIN_SET);
    if (HAL_UART_Receive_IT(&huart1, &console_rx_byte, 1U) != HAL_OK) { return 0; }
    if (HAL_UART_Receive_IT(&huart3, &wifi_rx_byte, 1U) != HAL_OK) { return 0; }
    return 1;
}

/**
 * @brief 返回 HAL 毫秒时基；计时使用无符号差值以兼容计数器回绕。
 */
uint32_t board_io_now(void) { return HAL_GetTick(); }
/**
 * @brief 从 Wi-Fi 接收队列取一个字节；成功返回 1，无数据返回 0。
 */
int board_io_wifi_read(uint8_t *byte) { return ring_pop(&wifi_ring, byte); }
/**
 * @brief 从调试串口接收队列取一个字节；成功返回 1，无数据返回 0。
 */
int board_io_console_read(uint8_t *byte) { return ring_pop(&console_ring, byte); }
/**
 * @brief 查询 Wi-Fi 串口是否仍有中断发送事务未完成。
 */
int board_io_wifi_tx_busy(void) { return tx_busy != 0U; }

/**
 * @brief 在短临界区内取出并清除 Wi-Fi 错误标志，避免与中断同时更新。
 */
int board_io_wifi_fault(void)
{
    uint32_t mask = __get_PRIMASK();
    uint8_t error;
    __disable_irq();
    error = wifi_error;
    wifi_error = 0U;
    __set_PRIMASK(mask);
    return error != 0U;
}

/**
 * @brief 复制数据到专用发送缓冲区并启动中断发送；忙、超长或启动失败返回 0。
 */
int board_io_wifi_send(const uint8_t *data, size_t length)
{
    if (data == NULL || length == 0U || length > sizeof(wifi_tx) || tx_busy) { return 0; }
    memcpy(wifi_tx, data, length);
    tx_busy = 1U;
    if (HAL_UART_Transmit_IT(&huart3, wifi_tx, (uint16_t)length) != HAL_OK) {
        tx_busy = 0U;
        return 0;
    }
    return 1;
}

/**
 * @brief 通过调试串口输出文本；仅主循环调用，单次最多 220 字节并限制发送等待时间。
 */
void board_io_log(const char *text)
{
    size_t length;
    if (text == NULL) { return; }
    length = strlen(text);
    /* 仅主循环输出日志，限制阻塞时间；中断中不输出日志，也不记录凭据。 */
    if (length > 220U) { length = 220U; }
    if (length && HAL_UART_Transmit(&huart1, (const uint8_t *)text, (uint16_t)length, 30U) != HAL_OK) {
        console_error = 1U;
    }
}

/**
 * @brief asserted 非零时拉低复位脚，并中止收发、清空旧接收数据；为零时释放复位。
 */
void board_io_wifi_reset(int asserted)
{
    uint32_t mask;
    HAL_GPIO_WritePin(ESP_RST_GPIO_Port, ESP_RST_Pin, asserted ? GPIO_PIN_RESET : GPIO_PIN_SET);
    if (!asserted) { return; }
    (void)HAL_UART_AbortTransmit(&huart3);
    (void)HAL_UART_AbortReceive(&huart3);
    mask = __get_PRIMASK();
    __disable_irq();
    wifi_ring.head = 0U;
    wifi_ring.tail = 0U;
    wifi_error = 0U;
    tx_busy = 0U;
    __set_PRIMASK(mask);
    if (HAL_UART_Receive_IT(&huart3, &wifi_rx_byte, 1U) != HAL_OK) { wifi_error = 1U; }
}

/**
 * @brief 开始 AT 握手前清除启动噪声、串口溢出标志和旧接收队列，再开启接收。
 */
void board_io_wifi_prepare_rx(void)
{
    uint32_t mask;
    /* 开始 AT 握手前丢弃复位期间的数据与串口错误。 */
    (void)HAL_UART_AbortReceive(&huart3);
    mask = __get_PRIMASK();
    __disable_irq();
    __HAL_UART_CLEAR_OREFLAG(&huart3);
    wifi_ring.head = wifi_ring.tail = 0U;
    wifi_error = 0U;
    __set_PRIMASK(mask);
    if (HAL_UART_Receive_IT(&huart3, &wifi_rx_byte, 1U) != HAL_OK) { wifi_error = 1U; }
}

/**
 * @brief 按位控制 RGB：bit0 红、bit1 绿、bit2 蓝；板载 LED 为低电平点亮。
 */
void board_io_rgb(uint8_t mask)
{
    rgb_mask = mask & 7U;
    HAL_GPIO_WritePin(RED_RGB_GPIO_Port, RED_RGB_Pin, (mask & 1U) ? GPIO_PIN_RESET : GPIO_PIN_SET);
    HAL_GPIO_WritePin(GREEN_RGB_GPIO_Port, GREEN_RGB_Pin, (mask & 2U) ? GPIO_PIN_RESET : GPIO_PIN_SET);
    HAL_GPIO_WritePin(BLUE_RGB_GPIO_Port, BLUE_RGB_Pin, (mask & 4U) ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

/**
 * @brief 返回当前 RGB 位掩码，范围为 0～7。
 */
uint8_t board_io_rgb_get(void) { return rgb_mask; }

/**
 * @brief 开启蜂鸣器指定毫秒，最长 1000 毫秒；传入 0 立即关闭。
 */
void board_io_beep(uint32_t duration_ms)
{
    if (duration_ms > 1000U) { duration_ms = 1000U; }
    beep_duration = duration_ms;
    beep_started = board_io_now();
    beep_active = duration_ms != 0U;
    HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, beep_active ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/**
 * @brief 返回蜂鸣器是否处于定时鸣响状态。
 */
int board_io_beep_active(void) { return beep_active != 0U; }

/**
 * @brief 主循环维护蜂鸣器到时关闭，并尝试恢复调试串口接收。
 */
void board_io_process(void)
{
    if (beep_active && (uint32_t)(board_io_now() - beep_started) >= beep_duration) { board_io_beep(0U); }
    if (console_error) {
        console_error = 0U;
        (void)HAL_UART_AbortReceive(&huart1);
        if (HAL_UART_Receive_IT(&huart1, &console_rx_byte, 1U) != HAL_OK) { console_error = 1U; }
    }
}

/**
 * @brief 接收中断回调：只入队并重新挂接单字节接收，协议解析由主循环完成。
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart)
{
    if (uart == &huart3) {
        if (!ring_push(&wifi_ring, wifi_rx_byte)) { wifi_error = 1U; }
        if (HAL_UART_Receive_IT(uart, &wifi_rx_byte, 1U) != HAL_OK) { wifi_error = 1U; }
    } else if (uart == &huart1) {
        if (!ring_push(&console_ring, console_rx_byte)) { console_error = 1U; }
        if (HAL_UART_Receive_IT(uart, &console_rx_byte, 1U) != HAL_OK) { console_error = 1U; }
    }
}

/**
 * @brief 发送完成中断回调：释放 Wi-Fi 发送忙标志。
 */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *uart)
{
    if (uart == &huart3) { tx_busy = 0U; }
}

/**
 * @brief 串口错误中断回调：仅记录错误，交由主循环恢复。
 */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *uart)
{
    if (uart == &huart3) { wifi_error = 1U; }
    if (uart == &huart1) { console_error = 1U; }
}
