/**
 * @file servo_io.c
 * @brief 舵机总线适配：将逻辑总线编号映射到 STM32 HAL I2C，集中处理地址与超时。
 */
#include "servo_io.h"
#include "i2c.h"
#include <string.h>
#include <stddef.h>

#define SERVO_IO_TIMEOUT_MS 5U
#define SERVO_IO_MAX_WRITE 4U

/**
 * @brief 逻辑总线 0 对应 hi2c1，逻辑总线 1 对应 hi2c2；其他编号返回空指针。
 */
static I2C_HandleTypeDef *get_bus(uint8_t bus)
{
    if (bus == 0U) { return &hi2c1; }
    if (bus == 1U) { return &hi2c2; }
    return NULL;
}

/**
 * @brief 同步写寄存器，最多四字节、超时五毫秒；输入为七位地址，左移后传给 HAL。
 */
int servo_io_write(uint8_t bus, uint8_t address, uint8_t reg,
                   const uint8_t *data, uint16_t length)
{
    uint8_t buffer[SERVO_IO_MAX_WRITE];
    I2C_HandleTypeDef *handle = get_bus(bus);
    if (!handle || !data || !length || length > sizeof(buffer) || address > 0x7FU) { return 0; }
    memcpy(buffer, data, length);
    return HAL_I2C_Mem_Write(handle, (uint16_t)(address << 1), reg,
                            I2C_MEMADD_SIZE_8BIT, buffer, length, SERVO_IO_TIMEOUT_MS) == HAL_OK;
}

/**
 * @brief 同步读取一个八位寄存器；成功返回 1，参数错误或 HAL 通信失败返回 0。
 */
int servo_io_read(uint8_t bus, uint8_t address, uint8_t reg, uint8_t *value)
{
    I2C_HandleTypeDef *handle = get_bus(bus);
    if (!handle || !value || address > 0x7FU) { return 0; }
    return HAL_I2C_Mem_Read(handle, (uint16_t)(address << 1), reg,
                           I2C_MEMADD_SIZE_8BIT, value, 1U, SERVO_IO_TIMEOUT_MS) == HAL_OK;
}

/**
 * @brief 提供设备初始化所需的毫秒延时，只在主循环上下文使用。
 */
void servo_io_delay_ms(uint32_t milliseconds)
{
    HAL_Delay(milliseconds);
}
