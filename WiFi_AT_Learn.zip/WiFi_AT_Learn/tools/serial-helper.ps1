Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:serial = New-Object System.IO.Ports.SerialPort
$script:serial.BaudRate = 115200
$script:serial.DataBits = 8
$script:serial.Parity = [System.IO.Ports.Parity]::None
$script:serial.StopBits = [System.IO.Ports.StopBits]::One
$script:serial.Handshake = [System.IO.Ports.Handshake]::None
$script:serial.Encoding = [System.Text.Encoding]::ASCII
$script:serial.WriteTimeout = 500
$script:serial.ReadTimeout = 100
$script:serial.DtrEnable = $false
$script:serial.RtsEnable = $false

$form = New-Object System.Windows.Forms.Form
$form.Text = 'WiFi AT Serial Helper'
$form.ClientSize = New-Object System.Drawing.Size(780, 520)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.MinimumSize = New-Object System.Drawing.Size(796, 559)

function Add-Button($text, $x, $y, $width) {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $text
    $button.Location = New-Object System.Drawing.Point($x, $y)
    $button.Size = New-Object System.Drawing.Size($width, 32)
    $form.Controls.Add($button)
    return $button
}

$ports = New-Object System.Windows.Forms.ComboBox
$ports.DropDownStyle = 'DropDownList'
$ports.Location = New-Object System.Drawing.Point(12, 14)
$ports.Size = New-Object System.Drawing.Size(115, 30)
$form.Controls.Add($ports)
$refresh = Add-Button 'Refresh ports' 137 12 120
$connect = Add-Button 'Open port' 267 12 110

$baud = New-Object System.Windows.Forms.ComboBox
$baud.DropDownStyle = 'DropDownList'
$baud.Location = New-Object System.Drawing.Point(392, 14)
$baud.Size = New-Object System.Drawing.Size(115, 30)
$baud.Items.AddRange(@('115200', '9600', '57600', '38400', '19200', '74880'))
$baud.SelectedIndex = 0
$form.Controls.Add($baud)

$status = New-Object System.Windows.Forms.Label
$status.Text = 'Closed | 8N1 | No flow control'
$status.Location = New-Object System.Drawing.Point(12, 56)
$status.Size = New-Object System.Drawing.Size(750, 25)
$form.Controls.Add($status)

$log = New-Object System.Windows.Forms.TextBox
$log.Multiline = $true
$log.ReadOnly = $true
$log.ScrollBars = 'Both'
$log.WordWrap = $false
$log.Font = New-Object System.Drawing.Font('Consolas', 10)
$log.Location = New-Object System.Drawing.Point(12, 85)
$log.Size = New-Object System.Drawing.Size(756, 320)
$log.Anchor = 'Top, Bottom, Left, Right'
$form.Controls.Add($log)

$command = New-Object System.Windows.Forms.TextBox
$command.Text = 'AT'
$command.Location = New-Object System.Drawing.Point(12, 420)
$command.Size = New-Object System.Drawing.Size(640, 28)
$command.Anchor = 'Bottom, Left, Right'
$form.Controls.Add($command)
$send = Add-Button 'Send + CRLF' 662 417 106
$send.Anchor = 'Bottom, Right'
$test = Add-Button 'Send AT' 12 465 110
$version = Add-Button 'AT+GMR' 132 465 110
$clear = Add-Button 'Clear log' 252 465 110
foreach ($button in @($test, $version, $clear)) { $button.Anchor = 'Bottom, Left' }

function Write-Log([string]$message) {
    if ($log.TextLength -gt 150000) { $log.Clear() }
    $log.AppendText($message)
}

function Refresh-Ports {
    $previous = [string]$ports.SelectedItem
    $ports.Items.Clear()
    $names = @([System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object)
    foreach ($name in $names) { [void]$ports.Items.Add($name) }
    if ($ports.Items.Count -gt 0) {
        if ($ports.Items.Contains($previous)) { $ports.SelectedItem = $previous }
        else { $ports.SelectedIndex = 0 }
    } else {
        $status.Text = 'No COM ports. Connect the board CH340 USB, then Refresh ports.'
    }
}

function Close-Port {
    if ($script:serial.IsOpen) { $script:serial.Close() }
    $ports.Enabled = $true
    $baud.Enabled = $true
    $refresh.Enabled = $true
    $connect.Text = 'Open port'
    $status.Text = 'Closed | 8N1 | No flow control'
}

function Send-Command([string]$text) {
    if (-not $script:serial.IsOpen) {
        [void][System.Windows.Forms.MessageBox]::Show('Select a COM port and click Open port first.', 'Serial port')
        return
    }
    try {
        $script:serial.Write($text + "`r`n")
        Write-Log("`r`n[TX] " + $text + "`r`n")
    } catch { Write-Log("`r`n[ERROR] " + $_.Exception.Message + "`r`n") }
}

$refresh.Add_Click({ Refresh-Ports })
$connect.Add_Click({
    if ($script:serial.IsOpen) { Close-Port; return }
    if ($null -eq $ports.SelectedItem) { Refresh-Ports; return }
    try {
        $script:serial.PortName = [string]$ports.SelectedItem
        $script:serial.BaudRate = [int]$baud.SelectedItem
        $script:serial.Open()
        $ports.Enabled = $false
        $baud.Enabled = $false
        $refresh.Enabled = $false
        $connect.Text = 'Close port'
        $status.Text = 'Open: ' + $script:serial.PortName + ' | ' + $script:serial.BaudRate + ' | 8N1 | CR+LF'
        Write-Log("`r`n[OPEN] " + $status.Text + "`r`n")
    } catch {
        [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Cannot open serial port')
    }
})
$send.Add_Click({ Send-Command $command.Text })
$test.Add_Click({ Send-Command 'AT' })
$version.Add_Click({ Send-Command 'AT+GMR' })
$clear.Add_Click({ $log.Clear() })
$command.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $_.SuppressKeyPress = $true
        Send-Command $command.Text
    }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 50
$timer.Add_Tick({
    if ($script:serial.IsOpen) {
        try {
            $received = $script:serial.ReadExisting()
            if ($received.Length -gt 0) { Write-Log $received }
        } catch {
            Write-Log("`r`n[ERROR] " + $_.Exception.Message + "`r`n")
            Close-Port
        }
    }
})
$form.Add_FormClosed({
    $timer.Stop()
    $timer.Dispose()
    $script:serial.Dispose()
})
Refresh-Ports
$timer.Start()
[void]$form.ShowDialog()
