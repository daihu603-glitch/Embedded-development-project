@echo off
set "GUIDE_PYTHON=C:\Users\m1332\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%GUIDE_PYTHON%" (
  "%GUIDE_PYTHON%" "%~dp0tools\mqtt_control.py"
) else (
  py -3 "%~dp0tools\mqtt_control.py"
)
if errorlevel 1 pause
