#ifndef WIFI_WEB_H
#define WIFI_WEB_H

#include <stdbool.h>
#include <stdint.h>

/* Board-independent contracts; implementations in main.c use STM32 HAL. */
typedef struct
{
  bool (*tx_ready)(void);
  bool (*write)(const uint8_t *data, uint16_t length);
  void (*set_led)(bool on);
  void (*log)(const char *message);
} wifi_web_io_t;

void wifi_web_init(const wifi_web_io_t *io, uint32_t now);
void wifi_web_feed(uint8_t byte, uint32_t now);
void wifi_web_process(uint32_t now);
void wifi_web_rx_lost(void);
bool wifi_web_is_ready(void);

#endif
