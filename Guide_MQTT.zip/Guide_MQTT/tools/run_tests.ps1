param(
    [string]$Gcc = 'C:\mingw64\bin\gcc.exe',
    [string]$Python = 'C:\Users\m1332\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
)
$ErrorActionPreference = 'Stop'
Push-Location (Split-Path $PSScriptRoot -Parent)
try {
    & $Gcc -std=c99 -Wall -Wextra -Werror -ICore/Inc Core/Src/mqtt_codec.c Core/Src/mqtt_endpoint.c tests/test_mqtt.c -o tests/test_mqtt.exe
    if ($LASTEXITCODE -ne 0) { throw 'Protocol test build failed' }
    & .\tests\test_mqtt.exe
    if ($LASTEXITCODE -ne 0) { throw 'Protocol tests failed' }
    & $Gcc -std=c99 -Wall -Wextra -Werror -ICore/Inc Core/Src/mqtt_codec.c Core/Src/mqtt_endpoint.c Core/Src/esp_at.c Core/Src/app_mqtt.c tests/test_app.c -o tests/test_app.exe
    if ($LASTEXITCODE -ne 0) { throw 'Application test build failed' }
    & .\tests\test_app.exe
    if ($LASTEXITCODE -ne 0) { throw 'Application tests failed' }
    & $Python -m py_compile tools/mqtt_control.py tools/sync_keil.py
    if ($LASTEXITCODE -ne 0) { throw 'Python syntax check failed' }
    & $Python -c 'import tkinter; print("PASS: Python Tkinter available")'
    if ($LASTEXITCODE -ne 0) { throw 'Tkinter dependency unavailable' }
} finally {
    Pop-Location
}
