# 指南者板载 Wi-Fi / MQTT 控制

这一版实现手机或电脑直接连接开发板热点，以 MQTT 控制板载 RGB 灯和蜂鸣器。ESP8266 运行原有 AT 固件并提供 Wi-Fi / TCP；STM32 运行精简 MQTT 3.1.1 服务端。运行时无需电脑充当 Broker，也不需要路由器或互联网。

当前没有舵机、PCA9685 或步态代码。工程保持 CubeMX 已配置的引脚、时钟和初始化；main.c 的应用入口只放在 USER CODE 区域。

## 第一次使用

1. 在 Keil 重新打开 `MDK-ARM/Guide_MQTT.uvprojx`，让外部修改生效。工程树应有 `Application/User/MQTT` 分组及五个 C 文件。
2. 选择 `Guide_MQTT` target，Build。通过已连接的 DAP 下载到 STM32；下载器应选择实际连接的 CMSIS-DAP，调试接口为 SWD。这里不更改保护位、不擦除 ESP8266 固件。
3. 开发板正常供电并复位。原 PB10/PB11 Wi-Fi 串口跳帽保持拔掉，接线为 PD8→URX、PD9←UTX。可用另一根 USB 数据线连接板上标有 **USB 转串口** 的接口查看启动日志：115200、8N1、无流控。**USB DEVICE 口和 DAP 连接不是这个日志串口。**
4. 正常初始化结束时，日志包含 `[READY] WiFi: senyu | MQTT 192.168.4.1:1883`。手机或电脑连接 `senyu` 热点，密码使用你提供的密码（已写入 `Core/Inc/app_config.h`）。系统提示 Wi-Fi 无互联网时，选择保持连接。
5. 电脑可双击工程根目录 `Open-MQTT-Control.cmd`，点击“连接”，再点颜色或短鸣按钮。脚本需要 Python 3 + Tkinter；已为本机 Python 路径设置启动项。这个工具是电脑程序，不是手机网页。
6. 手机使用支持下表选项的 MQTT 客户端，订阅 `guide/#`，再发布命令。不同手机 App 的按钮位置不同，但连接参数相同。

## MQTT 连接参数

| 项目 | 值 |
| --- | --- |
| 连接方式 | 普通 MQTT TCP，非 WebSocket |
| Broker / Host | `192.168.4.1` |
| 端口 | `1883` |
| 协议版本 | MQTT 3.1.1 |
| Client ID | 任意 1～63 字节可打印 ASCII，例如 `senyu-phone`；每个客户端使用不同 ID |
| 用户名 / 密码 | 留空；Wi-Fi 密码仅在连接热点时输入 |
| Clean Session | 开启 |
| TLS / SSL | 关闭 |
| Will / 遗嘱 | 关闭 |
| 发布 QoS / Retain | `0` / 关闭 |
| Keep Alive | 建议 30 秒 |

本项目是有明确功能边界的嵌入式端点，不是完整通用 Broker：只处理上述连接方式、QoS 0 非保留发布、订阅/退订、心跳和断开。订阅可用 `+`、`#`，服务端授予 QoS 0；不支持会话持久化、遗嘱、用户名密码、TLS、QoS 1/2 发布或保留消息。超出支持范围可能被拒绝或断开，不能打开手机 App 的默认遗嘱/保留设置。

协议层最多管理 5 个 TCP 客户端，实际 Wi-Fi 同时接入数受 ESP8266 AT 固件限制；每个客户端最多 4 条订阅，数据包上限 512 字节，主题上限 79 字节、命令内容上限 95 字节，均为可打印 ASCII。设计用于少量控制指令，不用于高速遥测。

## 控制指令

发布内容为纯文本，不需要 JSON，也不要添加引号或换行。

| Topic | Payload 示例 | 行为 |
| --- | --- | --- |
| `guide/rgb` | `red` | 红灯 |
| `guide/rgb` | `green` / `blue` | 绿灯 / 蓝灯 |
| `guide/rgb` | `yellow` / `cyan` / `magenta` / `white` | 混色灯 |
| `guide/rgb` | `off` | 关灯 |
| `guide/beep` | `100` | 短鸣 100 毫秒 |
| `guide/beep` | `500` | 短鸣 500 毫秒 |
| `guide/beep` | `off` 或 `0` | 静音 |

蜂鸣时长只接受 0～1000 毫秒；无效内容不执行。定时到期、TCP 断开或网络复位会关闭蜂鸣器。RGB 保持最后设置，系统启动时关灯。此处仅开关颜色，没有 PWM 呼吸灯或蜂鸣器音阶。

订阅 `guide/state` 获取约每两秒及状态变化时发布的 JSON：`uptime` 为运行秒数，`rgb` 为红=1、绿=2、蓝=4 的位组合，`beep` 为开关状态，`clients` 为 MQTT 已连接数，`commands` 为收到的有效格式发布包数量。`commands` 不是成功动作计数。订阅 `guide/result` 查看 `ok rgb red` 等执行结果。`guide/#` 可同时查看命令回显和状态。

## 串口排查

串口发送使用 LF 或 CRLF 结尾。支持 `status`、`restart`、`rgb red`、`rgb off`、`beep 100`、`beep off`。`restart` 重新初始化 ESP8266 和 MQTT 服务，不重写其固件。

启动会查询 `AT+GMR`。用户实板日志已确认 AT 0.22.0.0 / SDK 1.0.0。网络配置优先使用 `_CUR` 命令；旧固件返回 ERROR 时尝试旧语法，其中热点 IP 回退为单参数 `AT+CIPAP="192.168.4.1"`，不再附带网关和掩码。旧语法可能保存设置到 ESP8266 Flash。命令超时、接收溢出或发送中连接中断时，程序会复位模块并重新配置热点。此回退已通过模拟测试及目标编译，还需实板确认能到达 `[READY]`。

- 没有任何串口日志：检查连接的是 USB 转串口接口、正确 COM 口、115200 波特率和开发板复位。
- 始终提示首条 AT 超时：检查 ESP8266 供电、115200 AT 固件和 PD8→URX、PD9←UTX 接线，原 PB10/PB11 跳帽保持拔掉。
- 后续 setup step 失败：保留从启动开始的完整日志和 AT 版本，用于判断指令兼容性。
- 手机连热点后无法 MQTT 连接：检查仍连接 senyu、地址端口、MQTT 3.1.1、关闭 TLS/Will/Retain，且用户名密码为空。
- MQTT 已连接但器件不动作：先串口发送 `rgb red` 或 `beep 100`，分别排查板载 GPIO 与网络链路。

## 引脚与模块

| 功能 | 当前引脚 |
| --- | --- |
| 红 / 绿 / 蓝 LED | PB5 / PB0 / PB1，低电平点亮 |
| 蜂鸣器 | PA8，高电平启用 |
| ESP8266 EN / RESET | PB8 / PB9 |
| ESP8266 串口 USART3 | PD8 TX → URX；PD9 RX ← UTX，完全重映射 |
| 日志串口 USART1 | PA9 TX / PA10 RX |
| SWD | PA13 / PA14 |

`board_io` 负责 HAL 与 UART 环形缓冲；`esp_at` 负责 AT / +IPD；`mqtt_codec` 负责报文编码与拆包；`mqtt_endpoint` 负责会话、订阅和路由；`app_mqtt` 负责热点初始化、输出队列与器件命令。中断只收发数据并记录错误，解析和控制在主循环进行。

网络参数及 Topic 位于 `Core/Inc/app_config.h`。USART3 已完全重映射至 PD8/PD9，PB6/PB7 接 I2C1、PB10/PB11 接 I2C2。当前已加入两块 PCA9685 舵机驱动：I2C1 的通道 0~8 对应舵机 ID 0~8，I2C2 的通道 0~8 对应舵机 ID 9~17。MQTT 使用 `guide/servo` 主题，文本命令示例：`0 90`、`9 90`、`0 off`、`off`、`status`；结果发布到 `guide/result`。舵机电源使用外部 UBEC，PCA9685 的逻辑 VCC 接 3.3 V，舵机电源 V+ 接 UBEC，开发板、PCA9685 和 UBEC 必须共地。

启动接收修复：模块复位后的 2 秒等待期间不解析 AT 数据；等待结束后清理 UART 接收错误和缓存并重新开启接收，再开始握手。运行阶段的 UART 错误与命令应答超时分别输出日志。此修改已通过模拟启动错误测试和 Keil 编译，实板是否能建立热点仍需重新下载验证。

## 重新生成与测试

CubeMX 保留 `Keep User Code when re-generating`。重新生成后先关闭 Keil 工程，运行 `python tools/sync_keil.py` 恢复用户模块分组，再打开工程编译。脚本只添加模块并检查 main.c 应用入口，不重写初始化；应用代码和配置请保留备份。

主机测试可运行 `tools/run_tests.ps1`（需要 GCC 和 Python），覆盖 MQTT 字节格式、分包、订阅路由、异常长度、超时、连接复用、AT 旧语法回退、100 条分段控制指令、蜂鸣时长、缺失发送提示符及发送中断线。主机测试使用模拟串口，不能证明真实 ESP8266、GPIO 或供电运行正常。

目标编译使用实际 Keil 工程，日志为 `build-mqtt.log`，输出为 `MDK-ARM/Guide_MQTT/Guide_MQTT.axf` 和 `.hex`。静态调用图的最大栈数字不包含全部间接调用和中断开销，不能代替板上栈高水位测试。

交付验证范围：主机协议/应用测试、Python 语法与依赖检查、Keil 编译链接。尚未由本次代码任务执行下载、实板联网、灯/蜂鸣器动作验证或手机客户端验收。

协议依据：[MQTT 3.1.1](https://docs.oasis-open.org/mqtt/mqtt/v3.1.1/os/mqtt-v3.1.1-os.html)、[ESP8266 AT 指令集 v1.5.4](https://www.espressif.com/sites/default/files/4a-esp8266_at_instruction_set_en_v1.5.4_0.pdf)。
