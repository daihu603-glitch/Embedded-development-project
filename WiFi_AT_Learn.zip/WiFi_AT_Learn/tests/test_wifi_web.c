#include "wifi_web.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint32_t now;
static char last_tx[2048];
static const uint8_t *active_tx;
static uint16_t active_length;
static bool tx_busy;
static bool led;
static uint32_t led_changes;
static uint32_t tx_count;
static bool modem_multi;
static bool modem_server;
static bool modem_has_links;

static bool fake_ready(void) { return !tx_busy; }
static bool fake_write(const uint8_t *data, uint16_t length)
{
  assert(length < sizeof(last_tx));
  memcpy(last_tx, data, length);
  last_tx[length] = '\0';
  active_tx = data;
  active_length = length;
  tx_count++;
  return true;
}
static void fake_led(bool on) { led = on; led_changes++; }
static void fake_log(const char *text) { (void)text; }
static const wifi_web_io_t io = {fake_ready, fake_write, fake_led, fake_log};

static void feed(const char *text)
{
  while (*text != '\0') { wifi_web_feed((uint8_t)*text++, now); }
}
static void ipd(uint8_t link, const char *payload)
{
  char header[48];
  (void)snprintf(header, sizeof(header), "+IPD,%u,%u:",
                 (unsigned int)link, (unsigned int)strlen(payload));
  feed(header);
  feed(payload);
}
static void setup_at(uint32_t start)
{
  static const char *expected[] = {
    "AT\r\n", "ATE0\r\n", "AT+CIPSERVER=0\r\n", "AT+CIPCLOSE=5\r\n",
    "AT+CIPMUX=0\r\n", "AT+CIPMODE=0\r\n",
    "AT+CWMODE_CUR=2\r\n", "AT+CWSAP_CUR=\"STM32_LED\",\"12345678\",6,3\r\n",
    "AT+CIPAP_CUR=\"192.168.4.1\",\"192.168.4.1\",\"255.255.255.0\"\r\n",
    "AT+CWDHCP_CUR=0,1\r\n", "AT+CIPMUX=1\r\n", "AT+CIPDINFO=0\r\n",
    "AT+CIPSERVER=1,80\r\n", "AT+CIPSTO=15\r\n"
  };
  size_t index;
  tx_busy = false;
  now = start;
  wifi_web_init(&io, now);
  now += 1500U;
  wifi_web_process(now);
  for (index = 0U; index < sizeof(expected) / sizeof(expected[0]); index++)
  {
    now++;
    wifi_web_process(now);
    assert(strcmp(last_tx, expected[index]) == 0);
    /* Model the observed legacy AT restrictions, keeping ESP state across
     * STM32 reinitializations instead of assuming a freshly powered module. */
    if (strcmp(last_tx, "AT+CIPSERVER=0\r\n") == 0)
    {
      bool was_running = modem_server;
      modem_server = false;
      feed(was_running ? "\r\nOK\r\n" : "\r\nERROR\r\n");
    }
    else if (strcmp(last_tx, "AT+CIPCLOSE=5\r\n") == 0)
    {
      assert(!modem_server);
      modem_has_links = false;
      feed(modem_multi ? "\r\n0,CLOSED\r\nOK\r\n" : "\r\nERROR\r\n");
    }
    else
    {
      if (strcmp(last_tx, "AT+CIPMUX=0\r\n") == 0)
      {
        assert(!modem_server && !modem_has_links);
        modem_multi = false;
      }
      else if (strcmp(last_tx, "AT+CIPMODE=0\r\n") == 0)
      {
        assert(!modem_multi && !modem_server && !modem_has_links);
      }
      else if (strcmp(last_tx, "AT+CIPMUX=1\r\n") == 0)
      {
        modem_multi = true;
      }
      else if (strcmp(last_tx, "AT+CIPSERVER=1,80\r\n") == 0)
      {
        assert(modem_multi);
        modem_server = true;
      }
      feed("\r\nOK\r\n");
    }
  }
  wifi_web_process(++now);
  assert(wifi_web_is_ready());
  assert(!led);
}
static void start_response(uint8_t link)
{
  char prefix[32];
  wifi_web_process(++now);
  wifi_web_process(++now);
  (void)snprintf(prefix, sizeof(prefix), "AT+CIPSEND=%u,", (unsigned int)link);
  assert(strncmp(last_tx, prefix, strlen(prefix)) == 0);
  feed("\r\nOK\r\n> ");
  wifi_web_process(++now);
}
static void finish_response(uint8_t link)
{
  char close[48];
  feed("\r\nSEND OK\r\n");
  wifi_web_process(++now);
  (void)snprintf(close, sizeof(close), "AT+CIPCLOSE=%u\r\n", (unsigned int)link);
  assert(strcmp(last_tx, close) == 0);
  (void)snprintf(close, sizeof(close), "\r\n%u,CLOSED\r\nOK\r\n", (unsigned int)link);
  feed(close);
}
static void check_http(const char *status)
{
  const char *header_end = strstr(last_tx, "\r\n\r\n");
  const char *length = strstr(last_tx, "Content-Length: ");
  assert(strncmp(last_tx, status, strlen(status)) == 0);
  assert(header_end != NULL && length != NULL);
  assert(strtoul(length + strlen("Content-Length: "), NULL, 10) == strlen(header_end + 4));
  assert(strstr(last_tx, "Connection: close\r\n") != NULL);
  assert(active_length <= 2048U);
}

int main(void)
{
  uint32_t before;
  char long_request[280];
  uint32_t cycle;

  setup_at(0U);
  modem_has_links = true;
  setup_at(0U);
  assert(modem_multi && modem_server && !modem_has_links);
  puts("PASS: cold boot and STM32 restart with ESP server and client retained");
  ipd(0U, "GET /o");
  wifi_web_process(++now);
  assert(!led);
  ipd(0U, "n HTTP/1.1\r\nHost: 192.168.4.1\r\n");
  wifi_web_process(++now);
  assert(!led); /* Must wait for complete HTTP headers. */
  ipd(0U, "\r\n");
  start_response(0U);
  assert(led);
  check_http("HTTP/1.1 200 OK");
  assert(strstr(last_tx, "href='/on'") != NULL);
  finish_response(0U);

  ipd(1U, "GET /off HTTP/1.1\r\nHost: test\r\n\r\n");
  start_response(1U);
  assert(!led);
  check_http("HTTP/1.1 200 OK");
  finish_response(1U);
  puts("PASS: fragmented +IPD/HTTP, header completion, on/off, HTTP byte lengths");

  before = led_changes;
  ipd(9U, "GET /on HTTP/1.1\r\n\r\n");
  wifi_web_process(++now);
  assert(led_changes == before);
  ipd(2U, "GET /onion HTTP/1.1\r\nX-Fake: GET /on HTTP/1.1\r\n\r\n");
  start_response(2U);
  check_http("HTTP/1.1 404 Not Found");
  assert(led_changes == before);
  finish_response(2U);
  puts("PASS: invalid link drained, exact action paths, no action from headers");

  ipd(0U, "GET /on HTTP/1.1\r\n\r\n");
  ipd(1U, "GET /off HTTP/1.1\r\n\r\n");
  start_response(0U);
  assert(led);
  tx_busy = true;
  wifi_web_process(++now);
  assert(memcmp(active_tx, last_tx, active_length) == 0);
  tx_busy = false;
  finish_response(0U);
  start_response(1U);
  assert(!led);
  finish_response(1U);
  puts("PASS: two queued clients, serialized modem TX, stable asynchronous buffers");

  for (cycle = 0U; cycle < 100U; cycle++)
  {
    ipd(0U, "GET /on HTTP/1.1\r\n\r\n");
    start_response(0U);
    feed("\r\nSEND OK\r\n");
    wifi_web_process(++now);
    assert(strcmp(last_tx, "AT+CIPCLOSE=0\r\n") == 0);
    feed("\r\n0,CLOSED\r\n");
    /* A browser can reuse this ID before the previous close result arrives. */
    feed("\r\n0,CONNECT\r\n");
    ipd(0U, "GET /off HTTP/1.1\r\n\r\n");
    before = tx_count;
    wifi_web_process(++now);
    wifi_web_process(++now);
    assert(tx_count == before);
    feed(cycle % 2U == 0U ? "\r\nUNLINK\r\nERROR\r\n" : "\r\nOK\r\n");
    start_response(0U);
    assert(!led);
    finish_response(0U);
  }
  puts("PASS: 100 repeated on/off cycles, split CLOSED/results, reused link IDs");

  ipd(0U, "GET /on HTTP/1.1\r\n\r\n");
  start_response(0U);
  feed("\r\n0,CLOSED\r\n");
  ipd(1U, "GET /off HTTP/1.1\r\n\r\n");
  before = tx_count;
  wifi_web_process(++now);
  assert(tx_count == before);
  feed("\r\nSEND OK\r\n");
  start_response(1U); /* Do not close an already closed link. */
  assert(!led);
  finish_response(1U);
  puts("PASS: peer closes before SEND OK, pending client waits for terminal result");

  ipd(0U, "GET /on HTTP/1.1\r\n\r\n");
  wifi_web_process(++now);
  wifi_web_process(++now);
  feed("\r\n0,CLOSED\r\n");
  ipd(1U, "GET /off HTTP/1.1\r\n\r\n");
  before = tx_count;
  wifi_web_process(++now);
  assert(tx_count == before);
  feed("\r\nERROR\r\n");
  start_response(1U);
  finish_response(1U);
  puts("PASS: peer closes before CIPSEND prompt, ERROR drained before next request");

  ipd(0U, "GET /on HTTP/1.1\r\n\r\n");
  start_response(0U);
  feed("\r\nSEND OK\r\n");
  wifi_web_process(++now);
  feed("\r\n0,CLOSED\r\n");
  now += 5001U;
  wifi_web_process(now);
  assert(!wifi_web_is_ready());
  setup_at(0U);
  puts("PASS: missing close result triggers setup recovery instead of command overlap");

  memset(long_request, 'a', sizeof(long_request));
  memcpy(long_request, "GET /on", 7U);
  memcpy(long_request + sizeof(long_request) - 16U, " HTTP/1.1\r\n\r\n", 13U);
  long_request[sizeof(long_request) - 3U] = '\0';
  ipd(3U, long_request);
  before = led_changes;
  start_response(3U);
  check_http("HTTP/1.1 400 Bad Request");
  assert(led_changes == before);
  finish_response(3U);
  puts("PASS: oversized request safely rejected");

  setup_at(0xFFFFFF00U);
  feed("\r\nready\r\n");
  wifi_web_process(++now);
  assert(!wifi_web_is_ready());
  now += 1500U;
  wifi_web_process(now);
  wifi_web_process(++now);
  assert(strcmp(last_tx, "AT\r\n") == 0);
  now += 5001U;
  wifi_web_process(now);
  assert(!wifi_web_is_ready());
  now += 3000U;
  wifi_web_process(now);
  wifi_web_process(++now);
  now += 1500U;
  wifi_web_process(now);
  wifi_web_process(++now);
  assert(strcmp(last_tx, "AT\r\n") == 0);
  puts("PASS: tick wraparound, modem reboot detection, setup timeout/retry");

  setup_at(0U);
  ipd(0U, "GET /on HTTP/1.1\r\n");
  now += 10001U;
  wifi_web_process(now);
  wifi_web_process(++now);
  assert(strcmp(last_tx, "AT+CIPCLOSE=0\r\n") == 0);
  feed("\r\n0,CLOSED\r\nOK\r\n");
  assert(!led);
  wifi_web_rx_lost();
  wifi_web_process(++now);
  assert(!wifi_web_is_ready());
  puts("PASS: partial request timeout, RX overflow invalidates pending parsing");

  setup_at(0U);
  feed("+IPD,0,500:GET /o");
  now += 5001U;
  wifi_web_process(now);
  assert(!wifi_web_is_ready());
  assert(!led);
  now += 3000U;
  wifi_web_process(now);
  wifi_web_process(++now);
  now += 1500U;
  wifi_web_process(now);
  wifi_web_process(++now);
  assert(strcmp(last_tx, "AT\r\n") == 0);
  puts("PASS: truncated +IPD payload cannot trap the parser indefinitely");
  puts("All WiFi web protocol tests passed.");
  return 0;
}
